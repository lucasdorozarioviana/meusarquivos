# -*- encoding: cp850 -*-
import time
from ctypes import * 
from sys import *

library = CDLL("libbemafiscal.so")

iACK = c_int()
iST1 = c_int()
iST2 = c_int()
iST3 = c_int()
ncupom = " " * 10
contadorcomprovante = " " * 5
contadorRelatotioGerencial = " " * 7
cNumero = " " * 10
contadorCupomFiscal = " " * 7

repetir = 0
nvendas = 0
#Habilitar Retorno Estendido
retorno = library.Bematech_FI_HabilitaDesabilitaRetornoEstendidoMFD("1")
retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
print "Retorno Habilita Retorno Estendido"
print iACK.value, iST1.value, iST2.value, iST3.value

while repetir < 1:
        
	#Abre Cupom
	retorno = library.Bematech_FI_AbreCupom("")
	retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
	print "Retorno Abre Cupom"
	print iACK.value, iST1.value, iST2.value, iST3.value
	while nvendas < 1: # Caso queira looping de itens de venda, aumentar o numero de 1 para o que quiser!!!

                #Vende Item
		retorno = library.Bematech_FI_VendeItem("123", "Escudo do Capitao America", "FF", "I", "10", 2, "50,00", "%", "0000")
		retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
		print "Retorno Vende Item"
		print iACK.value, iST1.value, iST2.value, iST3.value
		nvendas = nvendas + 1 

                #Iniciar Fechamento do cupom
		retorno =  library.Bematech_FI_IniciaFechamentoCupom("A", "%", "1000")
	retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
	print "Retorno Inicia Fechamento Cupom"
	print iACK.value, iST1.value, iST2.value, iST3.value

        #Efetua Pagamento do Cupom
	retorno = library.Bematech_FI_EfetuaFormaPagamento("Dinheiro", "5000,00")
	retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
	print "Retorno Efetua Forma de Pagamento"
	print iACK.value, iST1.value, iST2.value, iST3.value	
	repetir = repetir + 1 # Caso queira looping do processo completo de de vendas, comentar essa linha!!!

        #Fechamento do Cupom
	retorno = library.Bematech_FI_TerminaFechamentoCupom("Obrigado, volte sempre !!!")
	retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
	print "Retorno Termina Fechamento Cupom"
	print iACK.value, iST1.value, iST2.value, iST3.value
	
	

#Lucas Viana - BSP
