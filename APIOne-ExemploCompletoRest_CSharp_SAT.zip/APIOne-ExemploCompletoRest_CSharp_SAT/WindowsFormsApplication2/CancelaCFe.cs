﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class CancelaCFe : Form
    {
        public CancelaCFe()
        {
            InitializeComponent();
        }

        private void BotaoSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Bematech_Fiscal_CancelarNota_Click(object sender, EventArgs e)
        {

            {
                try
                {

                    //Le um JSon de um arquivo texto
                    String Json = PainelCancelarNota.Text;
                    Json = Json.Replace("\n", String.Empty);
                    Json = Json.Replace("\r", String.Empty);
                    Json = Json.Replace("\t", String.Empty);

                    // Executa a Chamada de Função de Cancelar Cupom
                    String teste = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(OneAPI.OneAPI.Bematech_Fiscal_CancelarNota(Json));

                    //Mostra o JSon utilizado na tela e o retorno
                    PainelCancelarNota.Clear();
                    PainelCancelarNota.Text = Json;
                    PainelRetornoCancelarNota.AppendText(teste);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }


        }

        private void LimparCancela01_Click(object sender, EventArgs e)
        {
            PainelCancelarNota.Clear();
        }

        private void LimparCancela02_Click(object sender, EventArgs e)
        {
            PainelRetornoCancelarNota.Clear();
        }
    }
}
