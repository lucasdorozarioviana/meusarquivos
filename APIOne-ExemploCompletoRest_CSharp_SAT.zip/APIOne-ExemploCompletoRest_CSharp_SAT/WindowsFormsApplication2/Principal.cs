﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
//using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Runtime.InteropServices;
using OneAPI;



namespace WindowsFormsApplication2
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void AbreCupom_Click(object sender, EventArgs e)
        {
            try
            {

                //Le um JSon de um arquivo texto
                String Json = File.ReadAllText(Environment.CurrentDirectory + @"\AbreCupom.txt");
                Json = Json.Replace("\n", String.Empty);
                Json = Json.Replace("\r", String.Empty);
                Json = Json.Replace("\t", String.Empty);

                // Executa a Chamada de Função de abertura de Cupom
                String teste = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(OneAPI.OneAPI.Bematech_Fiscal_AbrirNota(Json));

                //Mostra o JSon utilizado na tela e o retorno
                PainelJsonComando.Clear();
                PainelJsonComando.Text = Json;
                PainelSaisadeComando.AppendText(teste);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void Principal_Load(object sender, EventArgs e)
        {


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void ConfigurarFM_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    //Le um JSon de um arquivo texto
                    string json = File.ReadAllText(Environment.CurrentDirectory + @"\EfetuarConfiguracoes.txt");
                    json = json.Replace("\n", String.Empty);
                    json = json.Replace("\r", String.Empty);
                    json = json.Replace("\t", String.Empty);

                    //Executa a Chamada de função de abertura de cupom
                    String teste = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(OneAPI.OneAPI.Bematech_Fiscal_EfetuarConfiguracoes(json));

                    //Mostra o JSon utilizado na tela e o retorno.
                    PainelJsonComando.Clear();
                    PainelJsonComando.Text = json;
                    PainelSaisadeComando.AppendText(teste);

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Bematech_Fiscal_VenderItem_Click(object sender, EventArgs e)
        {
            try
            {
                //Le um JSon de um arquivo texto
                string json = File.ReadAllText(Environment.CurrentDirectory + @"\VenderItem.txt");
                json = json.Replace("\n", String.Empty);
                json = json.Replace("\r", String.Empty);
                json = json.Replace("\t", String.Empty);

                //Executa a Chamada de função de abertura de cupom
                String teste = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(OneAPI.OneAPI.Bematech_Fiscal_VenderItem(json));

                //Mostra o JSon utilizado na tela e o retorno.
                PainelJsonComando.Clear();
                PainelJsonComando.Text = json;
                PainelSaisadeComando.AppendText(teste);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Bematech_Fiscal_EfetuarPagamento_Click(object sender, EventArgs e)
        {
            try
            {

                //Le um JSon de um arquivo texto
                string json = File.ReadAllText(Environment.CurrentDirectory + @"\EfetuarPagamento.txt");
                json = json.Replace("\n", String.Empty);
                json = json.Replace("\r", String.Empty);
                json = json.Replace("\t", String.Empty);

                //Executa a Chamada de função de abertura de cupom
                string teste = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(OneAPI.OneAPI.Bematech_Fiscal_EfetuarPagamento(json));

                //Mostra o JSon utilizado na tela e o retorno.
                PainelJsonComando.Clear();
                PainelJsonComando.Text = json;
                PainelSaisadeComando.AppendText(teste);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Bematech_Fiscal_FecharNota_Click(object sender, EventArgs e)
        {
            try

            {

                //Le um JSon de um arquivo texto
                string json = File.ReadAllText(Environment.CurrentDirectory + @"\FecharNota.txt");
                json = json.Replace("\n", String.Empty);
                json = json.Replace("\r", String.Empty);
                json = json.Replace("\t", String.Empty);

                //Executa a Chamada de função de abertura de cupom
                string teste = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(OneAPI.OneAPI.Bematech_Fiscal_FecharNota(json));

                //Mostra o JSon utilizado na tela e o retorno.
                PainelJsonComando.Clear();
                PainelJsonComando.Text = json;
                PainelSaisadeComando.AppendText(teste);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            PainelJsonComando.Clear();
        }

        private void Limpar02_Click(object sender, EventArgs e)
        {
            PainelSaisadeComando.Clear();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void closed_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ConsultarErroSefaz_Click(object sender, EventArgs e)
        {
            int RetornoSefaz;
            RetornoSefaz = Int32.Parse(CampoConsultaRejeicao.Text);
            switch (RetornoSefaz)
            {
                case 100:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("CF-e-SAT processado com sucesso");
                    break;
                case 101:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("CF-e-SAT de cancelamento processado com sucesso");
                    break;
                case 102:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("CF-e-SAT processado – verificar inconsistências");
                    break;
                case 103:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("CF-e-SAT de cancelamento processado – verificar inconsistências");
                    break;
                case 104:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Não Existe Atualização do Software");
                    break;
                case 105:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Lote recebido com sucesso");
                    break;
                case 106:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Lote Processado");
                    break;
                case 107:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Lote em Processamento");
                    break;
                case 108:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Lote não localizado");
                    break;
                case 109:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Serviço em Operação");
                    break;
                case 110:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Status SAT recebido com sucesso");
                    break;
                case 111:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Nova redação, efeitos a partir de 01.01.17: Erro no registro da assinatura do AC. Verificar dados.");
                    break;
                case 112:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Assinatura do AC Registrada");
                    break;
                case 113:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Consulta cadastro com uma ocorrência");
                    break;
                case 114:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Consulta cadastro com mais de uma ocorrência");
                    break;
                case 115:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Solicitação de dados efetuada com sucesso");
                    break;
                case 116:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Atualização do SB pendente");
                    break;
                case 117:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Solicitação de Arquivo de Parametrização efetuada com sucesso");
                    break;
                case 118:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Logs extraídos com sucesso");
                    break;
                case 119:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Comandos da SEFAZ pendentes");
                    break;
                case 120:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Não existem comandos da SEFAZ pendentes");
                    break;
                case 121:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Certificado Digital criado com sucesso");
                    break;
                case 122:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("CRT recebido com sucesso");
                    break;
                case 123:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Adiar transmissão do lote");
                    break;
                case 124:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Adiar transmissão do CF-e");
                    break;
                case 125:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("CF-e de teste de produção emitido com sucesso");
                    break;
                case 126:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("CF-e de teste de ativação emitido com sucesso");
                    break;
                case 127:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Erro na emissão de CF-e de teste de produção");
                    break;
                case 128:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Erro na emissão de CF-e de teste de ativação");
                    break;
                case 129:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Solicitações de emissão de certificados excedidas.");
                    break;
                case 130:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("ID do comando inexistente");
                    break;
                case 131:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Nova redação, efeitos a partir de 01.01.17: Confirmação de reset aceito: equipamento pode");
                    break;
                case 132:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("às configurações de fábrica.");
                    break;
                case 133:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Nova redação, efeitos a partir de 01.01.17: Rejeição: Equipamento não pode ser desativado.");
                    break;
                case 134:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Nova redação, efeitos a partir de 01.01.17: Solicitação de parâmetros de gestão efetuada com sucesso.");
                    break;
                case 199:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Cupom cancelamento rejeitado");
                    break;
                case 200:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Status do equipamento SAT difere");
                    break;
                case 201:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Falha na Verificação da Assinatura");
                    break;
                case 202:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Falha no reconhecimento da autoria");
                    break;
                case 203:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Emissor não Autorizado para emissão");
                    break;
                case 204:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Duplicidade de CF-e-SAT");
                    break;
                case 205:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Equipamento SAT encontra-se Ativo");
                    break;
                case 206:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Hora de Emissão do CF-e-SAT");
                    break;
                case 207:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do emitente inválido");
                    break;
                case 208:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Equipamento SAT encontra-se Desativado");
                    break;
                case 209:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: IE do emitente inválida");
                    break;
                case 210:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Intervalo de tempo entre o CF-e-SAT emitido e a emissão do respectivo CF-e-SAT de cancelamento é maior que 30 trinta minutos.");
                    break;
                case 211:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ não corresponde ao informado no processo de transferência.");
                    break;
                case 212:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Data de Emissão do CF-e-SAT posterior à data de recebimento.");
                    break;
                case 213:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ-Base do Emitente difere do CNPJ-Base do Certificado Digital");
                    break;
                case 214:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Tamanho da mensagem excedeu o limite estabelecido");
                    break;
                case 215:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Falha no schema XML");
                    break;
                case 216:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Chave de Acesso difere da cadastrada");
                    break;
                case 217:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CF-e-SAT não consta na base de dados da SEFAZ");
                    break;
                case 218:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CF-e-SAT já esta cancelado na base de dados da SEFAZ");
                    break;
                case 219:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ não corresponde ao informado no processo de declaração de posse.");
                    break;
                case 220:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do rateio do desconto sobre subtotal do item (N) inválido.");
                    break;
                case 221:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Aplicativo Comercial não vinculado ao SAT");
                    break;
                case 222:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Assinatura do Aplicativo Comercial inválida");
                    break;
                case 223:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do transmissor do lote difere do CNPJ do transmissor da consulta");
                    break;
                case 224:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ da Software House inválido");
                    break;
                case 225:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Falha no Schema XML do lote de CFe");
                    break;
                case 226:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código da UF do Emitente diverge da UF receptora");
                    break;
                case 227:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Erro na Chave de Acesso - Campo Id – falta a literal CFe");
                    break;
                case 228:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do rateio do acréscimo sobre subtotal do item (N) inválido.");
                    break;
                case 229:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: IE do emitente não informada");
                    break;
                case 230:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: IE do emitente não autorizada para uso do SAT");
                    break;
                case 231:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Alerta: IE do emitente não vinculada ao CNPJ");
                    break;
                case 232:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do destinatário do CF-e-SAT de cancelamento diferente daquele do CF-e-SAT a ser cancelado.");
                    break;
                case 233:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CPF do destinatário do CF-e-SAT de cancelamento diferente daquele do CF-e-SAT a ser cancelado.");
                    break;
                case 234:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Alerta: Razão Social/Nome do destinatário em branco");
                    break;
                case 235:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do destinatario inválido ou igual ao do emitente do CF-e-SAT");
                    break;
                case 236:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Chave de Acesso com dígito verificador inválido");
                    break;
                case 237:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CPF do destinatario Invalido");
                    break;
                case 238:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do emitente do CF-e-SAT de cancelamento diferente do CNPJ do CF-e-SAT a ser cancelado.");
                    break;
                case 239:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Versão do arquivo XML não suportada");
                    break;
                case 240:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor total do CF-e-SAT de cancelamento diferente do Valor total do CF-e-SAT a ser cancelado.");
                    break;
                case 241:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: diferença de transmissão e recebimento da mensagem superior a 5 minutos.");
                    break;
                case 242:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Alerta: CFe dentro do lote estão fora de ordem.");
                    break;
                case 243:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: XML Mal Formado");
                    break;
                case 244:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do Certificado Digital difere do CNPJ da Matriz e do CNPJ do Emitente");
                    break;
                case 245:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ Emitente não autorizado para uso do SAT");
                    break;
                case 246:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Campo cUF inexistente no elemento cfeCabecMsg do SOAP Header");
                    break;
                case 247:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Sigla da UF do Emitente diverge da UF receptora");
                    break;
                case 248:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: UF do Recibo diverge da UF autorizadora");
                    break;
                case 249:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: UF da Chave de Acesso diverge da UF receptora");
                    break;
                case 250:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: UF informada pelo SAT, não é atendida pelo Web Service");
                    break;
                case 251:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado enviado não confere com o escolhido na declaração de posse");
                    break;
                case 252:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Ambiente informado diverge do Ambiente de recebimento");
                    break;
                case 253:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Digito Verificador da chave de acesso composta inválida");
                    break;
                case 254:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Elemento cfeCabecMsg inexistente no SOAP Header");
                    break;
                case 255:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CSR enviado inválido");
                    break;
                case 256:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CRT enviado inválido");
                    break;
                case 257:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Número do série do equipamento inválido");
                    break;
                case 258:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Data e/ou hora do envio inválida");
                    break;
                case 259:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Versão do leiaute inválida");
                    break;
                case 260:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: UF inexistente");
                    break;
                case 261:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Assinatura digital não encontrada");
                    break;
                case 262:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ da software house não está ativo");
                    break;
                case 263:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do contribuinte não está ativo");
                    break;
                case 264:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Base da receita federal está indisponível");
                    break;
                case 265:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Número de série inexistente no cadastro do equipamento");
                    break;
                case 266:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Falha na comunicação com a AC-SAT");
                    break;
                case 267:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Erro desconhecido na geração do certificado pela AC-SAT");
                    break;
                case 268:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado está fora da data de validade.");
                    break;
                case 269:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Tipo de atividade inválida");
                    break;
                case 270:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Chave de acesso do CFe a ser cancelado inválido.");
                    break;
                case 271:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Ambiente informado no CF-e difere do Ambiente de recebimento cadastrado.");
                    break;
                case 272:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do troco negativo.");
                    break;
                case 273:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Serviço Solicitado Inválido");
                    break;
                case 274:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Equipamento não possui declaração de posse");
                    break;
                case 275:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Status do equipamento diferente de Fabricado");
                    break;
                case 276:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Diferença de dias entre a data de emissão e de recepção maior que o prazo legal");
                    break;
                case 277:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ do emitente não está ativo junto à Sefaz na data de emissão");
                    break;
                case 278:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: IE do emitente não está ativa junto à Sefaz na data de emissão");
                    break;
                case 279:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 280:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Transmissor Inválido");
                    break;
                case 281:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Transmissor Data Validade");
                    break;
                case 282:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Transmissor sem CNPJ");
                    break;
                case 283:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Transmissor - erro Cadeia de Certificação");
                    break;
                case 284:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Transmissor revogado");
                    break;
                case 285:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Transmissor difere ICP-Brasil");
                    break;
                case 286:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Transmissor erro no acesso a LCR");
                    break;
                case 287:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código Município do FG - ISSQN: dígito inválido. Exceto os códigos descritos no Anexo 2 que apresentam dígito inválido.");
                    break;
                case 288:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Data de emissão do CF-e-SAT a ser cancelado inválida");
                    break;
                case 289:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código da UF informada diverge da UF solicitada");
                    break;
                case 290:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Assinatura inválido");
                    break;
                case 291:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Assinatura Data Validade");
                    break;
                case 292:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Assinatura sem CNPJ");
                    break;
                case 293:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Assinatura - erro Cadeia de Certificação");
                    break;
                case 294:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Assinatura revogado");
                    break;
                case 295:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Raiz difere dos Válidos");
                    break;
                case 296:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Certificado Assinatura erro no acesso a LCR");
                    break;
                case 297:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Assinatura difere do calculado");
                    break;
                case 298:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Assinatura difere do padrão do Projeto");
                    break;
                case 299:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Hora de emissão do CF-e-SAT a ser cancelado inválida");
                    break;
                case 300:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 401:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 402:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: XML da área de dados com codificação diferente de UTF-8");
                    break;
                case 403:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Versão do leiaute do CF-e-SAT não é válida");
                    break;
                case 404:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Uso de prefixo de namespace não permitido");
                    break;
                case 405:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Alerta: Versão do leiaute do CF-e-SAT não é a mais atual");
                    break;
                case 406:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Versão do Software Básico do SAT não é valida.");
                    break;
                case 407:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Indicador de CF-e-SAT cancelamento inválido (diferente de ‘C’ e ‘’)");
                    break;
                case 408:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor total do CF-e-SAT maior que o somatório dos valores de Meio de Pagamento empregados em seu pagamento.");
                    break;
                case 409:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor total do CF-e-SAT supera o máximo permitido no arquivo de Parametrização de Uso");
                    break;
                case 410:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: UF informada no campo cUF não é atendida pelo Web Service");
                    break;
                case 411:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Campo versaoDados inexistente no elemento cfeCabecMsg do SOAP Header");
                    break;
                case 412:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CFe de cancelamento não corresponde ao CFe anteriormente gerado");
                    break;
                case 413:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 420:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Cancelamento para CF-e-SAT já cancelado");
                    break;
                case 450:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Modelo da CF-e-SAT diferente de 59");
                    break;
                case 451:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 452:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: número de série do SAT inválido ou não autorizado.");
                    break;
                case 453:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Ambiente de processamento inválido (diferente de 1 e 2)");
                    break;
                case 454:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ da Software House inválido");
                    break;
                case 455:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Assinatura do Aplicativo Comercial não é válida.");
                    break;
                case 456:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Regime tributário invalido");
                    break;
                case 457:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Natureza da Operação para ISSQN inválido");
                    break;
                case 458:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 459:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código do produto ou serviço em branco");
                    break;
                case 460:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: GTIN do item (N) inválido");
                    break;
                case 461:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Descrição do produto ou serviço em branco");
                    break;
                case 462:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CFOP não é de operação de saída prevista para CF-e-SAT");
                    break;
                case 463:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Unidade comercial do produto ou serviço em branco");
                    break;
                case 464:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Quantidade Comercial do item (N) inválido");
                    break;
                case 465:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor unitário do item (N) inválido");
                    break;
                case 466:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor bruto do item (N) difere de quantidade * Valor Unitário, considerando regra de arred/trunc.");
                    break;
                case 467:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Regra de calculo do item (N) inválida");
                    break;
                case 468:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do desconto do item (N) inválido");
                    break;
                case 469:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor de outras despesas acessórias do item (N) inválido.");
                    break;
                case 470:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor líquido do Item do CF-e difere de Valor Bruto de Produtos e Serviços - desconto + Outras Despesas Acessórias – rateio do desconto sobre subtotal + rateio do acréscimo sobre subtotal");
                    break;
                case 471:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: origem da mercadoria do item (N) inválido (difere de 0, 1, 2, 3, 4, 5, 6 e 7)");
                    break;
                case 472:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CST do Item (N) inválido (diferente de 00, 20, 90)");
                    break;
                case 473:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Alíquota efetiva do ICMS do item (N) inválido.");
                    break;
                case 474:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor líquido do ICMS do Item (N) difere de Valor do Item * Aliquota Efetiva");
                    break;
                case 475:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CST do Item (N) inválido (diferente de 40 e 41 e 50 e 60)");
                    break;
                case 476:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de situação da operação - Simples Nacional - do Item (N) inválido (diferente de 102, 300, 400 e 500)");
                    break;
                case 477:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de situação da operação - Simples Nacional - do Item (N) inválido (diferente de 900)");
                    break;
                case 478:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária do PIS Inválido (diferente de 01 e 02)");
                    break;
                case 479:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Base de cálculo do PIS do item (N) inválido.");
                    break;
                case 480:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Alíquota do PIS do item (N) inválido.");
                    break;
                case 481:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do PIS do Item (N) difere de Base de Calculo * Aliquota do PIS");
                    break;
                case 482:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária do PIS Inválido (diferente de 03)");
                    break;
                case 483:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Qtde Vendida do item (N) inválido.");
                    break;
                case 484:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Alíquota do PIS em R$ do item (N) inválido.");
                    break;
                case 485:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do PIS do Item (N) difere de Qtde Vendida* Aliquota do PIS em R$");
                    break;
                case 486:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária do PIS Inválido (diferente de 04, 06, 07, 08 e 09)");
                    break;
                case 487:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária do PIS inválido (diferente de 49)");
                    break;
                case 488:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária do PIS Inválido (diferente de 99)");
                    break;
                case 489:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do PIS do Item (N) difere de Qtde Vendida* Aliquota do PIS em R$ e difere de Base de Calculo * Aliquota do PIS");
                    break;
                case 490:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária da COFINS Inválido (diferente de 01 e 02)");
                    break;
                case 491:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Base de cálculo do COFINS do item (N) inválido.");
                    break;
                case 492:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Alíquota da COFINS do item (N) inválido.");
                    break;
                case 493:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor da COFINS do Item (N) difere de Base de Calculo * Aliquota da COFINS");
                    break;
                case 494:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária da COFINS Inválido (diferente de 03)");
                    break;
                case 495:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do COFINS do Item (N) difere de Qtde Vendida* Aliquota do COFINS em R$ e difere de Base de Calculo * Aliquota do COFINS");
                    break;
                case 496:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Alíquota da COFINS em R$ do item (N) inválido.");
                    break;
                case 497:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor da COFINS do Item (N) difere de Qtde Vendida* Aliquota da COFINS em R$");
                    break;
                case 498:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária da COFINS Inválido (diferente de 04, 06, 07, 08 e 09)");
                    break;
                case 499:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária da COFINS Inválido (diferente de 49)");
                    break;
                case 500:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Situação Tributária da COFINS Inválido (diferente de 99)");
                    break;
                case 501:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Operação com tributação de ISSQN sem informar a Inscrição Municipal");
                    break;
                case 502:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Erro na Chave de Acesso - Campo Id não corresponde à concatenação dos campos correspondentes");
                    break;
                case 503:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor das deduções para o ISSQN do item (N) inválido.");
                    break;
                case 504:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor da Base de Calculo do ISSQN do Item (N) difere de Valor do Item - Valor das deduções");
                    break;
                case 505:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Alíquota efetiva do ISSQN do item (N) não é maior ou igual a 2,00 (2%) e menor ou igual a 5,00 (5%).");
                    break;
                case 506:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Valor do ISSQN do Item (N) difere de Valor da Base de Calculo do ISSQN * Alíquota Efetiva do ISSQN");
                    break;
                case 507:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Indicador de rateio para ISSQN inválido");
                    break;
                case 508:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Item da lista de Serviços do ISSQN do item (N) inválido.");
                    break;
                case 509:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código municipal de Tributação do ISSQN do Item (N) em branco.");
                    break;
                case 510:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código de Natureza da Operação para ISSQN inválido");
                    break;
                case 511:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Indicador de Incentivo Fiscal do ISSQN do item (N) inválido (diferente de 1 e 2)");
                    break;
                case 512:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do PIS difere do somatório do PIS dos itens");
                    break;
                case 513:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do COFINS difere do somatório do COFINS dos itens");
                    break;
                case 514:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do PIS-ST difere do somatório do PIS-ST dos itens");
                    break;
                case 515:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do COFINs-STdifere do somatório do COFINS-ST dos itens");
                    break;
                case 516:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total de Outras Despesas Acessórias difere do somatório de Outras Despesas Acessórias (acréscimo) dos itens");
                    break;
                case 517:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total dos Itens difere do somatório do valor líquido dos itens");
                    break;
                case 518:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Informado grupo de totais do ISSQN sem informar grupo de valores de ISSQN");
                    break;
                case 519:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total da BC do ISSQN difere do somatório da BC do ISSQN dos itens");
                    break;
                case 520:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do ISSQN difere do somatório do ISSQN dos itens");
                    break;
                case 521:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do PIS sobre serviços difere do somatório do PIS dos itens de serviços");
                    break;
                case 522:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do COFINS sobre serviços difere do somatório do COFINS dos itens de serviços");
                    break;
                case 523:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do PIS-ST sobre serviços difere do somatório do PIS-ST dos itens de serviços");
                    break;
                case 524:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do COFINS-ST sobre serviços difere do somatório do COFINS-ST dos itens de serviços");
                    break;
                case 525:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor de Desconto sobre total inválido.");
                    break;
                case 526:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor de Acréscimo sobre total inválido.");
                    break;
                case 527:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Código do Meio de Pagamento inválido");
                    break;
                case 528:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor do Meio de Pagamento inválido.");
                    break;
                case 529:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor de desconto sobre subtotal difere do somatório dos seus rateios nos itens.");
                    break;
                case 530:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Operação com tributação de ISSQN sem informar a Inscrição Municipal");
                    break;
                case 531:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor de acréscimo sobre subtotal difere do somatório dos seus rateios nos itens.");
                    break;
                case 532:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do ICMS difere do somatório dos itens");
                    break;
                case 533:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor aproximado dos tributos do CF-e-SAT – Lei 12741/12 inválido");
                    break;
                case 534:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Valor aproximado dos tributos do Produto ou serviço – Lei 12741/12 inválido.");
                    break;
                case 535:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: código da credenciadora de cartão de débito ou crédito inválido");
                    break;
                case 536:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 537:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total do Desconto difere do somatório dos itens");
                    break;
                case 538:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 539:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Duplicidade de CF-e-SAT, com diferença na Chave de Acesso [99999999999999999999999999999999999999999]");
                    break;
                case 540:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: CNPJ da Software House + CNPJ do emitente assinado no campo “signAC” difere do informado no campo “CNPJvalue”");
                    break;
                case 541:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 555:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Tipo autorizador do protocolo diverge do Órgão Autorizador");
                    break;
                case 556:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 564:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Total dos Produtos ou Serviços difere do somatório do valor dos Produtos ou Serviços dos itens");
                    break;
                case 565:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 600:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Serviço Temporariamente Indisponível");
                    break;
                case 601:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 602:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Status do equipamento não permite ativação");
                    break;
                case 603:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Arquivo inválido");
                    break;
                case 604:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Erro desconhecido na verificação de comandos");
                    break;
                case 605:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Tamanho do arquivo inválido");
                    break;
                case 606:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 701:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado para aplicativo móvel");
                    break;
                case 751:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Nova redação, efeitos a partir de 01.01.17: Rejeição: não informado código do produto.");
                    break;
                case 752:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Nova redação, efeitos a partir de 01.01.17: Rejeição: código de produto informado fora do padrão ANP.");
                    break;
                case 753:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Reservado");
                    break;
                case 999:
                    PainelRetornoSefaz.Clear(); PainelRetornoSefaz.AppendText("Rejeição: Erro não catalogado");
                    break;





            }





        }

        private void PainelRetornoSefaz_TextChanged(object sender, EventArgs e)
        {

        }

        private void PainelJsonComando_TextChanged(object sender, EventArgs e)
        {

        }

        private void Bematech_Fiscal_CancelarNota_Click(object sender, EventArgs e)
        {
            CancelaCFe CancelaCFe = new CancelaCFe();
            CancelaCFe.Show();



        }

        private void CFeCompleto_Click(object sender, EventArgs e)
        {

            {
                try
                {

                    //Le um JSon de um arquivo texto
                    String Json = File.ReadAllText(Environment.CurrentDirectory + @"\VendaCompleta.txt");
                    Json = Json.Replace("\n", String.Empty);
                    Json = Json.Replace("\r", String.Empty);
                    Json = Json.Replace("\t", String.Empty);

                    // Executa a Chamada de Função de abertura de Cupom
                    String teste = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(OneAPI.OneAPI.Bematech_Fiscal_FecharNota(Json));

                    //Mostra o JSon utilizado na tela e o retorno
                    PainelJsonComando.Clear();
                    PainelJsonComando.Text = Json;
                    PainelSaisadeComando.AppendText(teste);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}

