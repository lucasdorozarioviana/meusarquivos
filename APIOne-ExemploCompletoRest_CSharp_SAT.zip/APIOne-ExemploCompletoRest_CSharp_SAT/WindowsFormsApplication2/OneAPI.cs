﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace OneAPI
{ 
public class OneAPI
{
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_AbrirNota(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_EstornarNota();
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_FecharNota(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_VenderItem(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_EstornarVendaItem(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_EfetuarPagamento(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_EstornarPagamento(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ListarNotas(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_InutilizarNumeracao(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ConsultarNota(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_EnviarNotaEmail(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_CancelarNota(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ObterStatusImpressora();
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ImprimirTextoLivre(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ImprimirDocumentoFiscal(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_AcionarGaveta(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ObterInformacoesSistema();
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ListarConfiguracoes();
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_EfetuarConfiguracoes(string dados);
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_ObterInformacoesContingencia();
    [DllImport("BemaOne32.dll")]    public static extern IntPtr Bematech_Fiscal_TrocarEstadoContingencia();
    
}
}
