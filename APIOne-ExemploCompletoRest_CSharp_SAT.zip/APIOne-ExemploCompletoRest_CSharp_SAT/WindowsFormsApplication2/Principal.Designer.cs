﻿namespace WindowsFormsApplication2
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.FuncoesVenda = new System.Windows.Forms.GroupBox();
            this.Bematech_Fiscal_FecharNota = new System.Windows.Forms.Button();
            this.Bematech_Fiscal_CancelarNota = new System.Windows.Forms.Button();
            this.Bematech_Fiscal_EfetuarPagamento = new System.Windows.Forms.Button();
            this.Bematech_Fiscal_VenderItem = new System.Windows.Forms.Button();
            this.Bematech_Fiscal_AbrirNota = new System.Windows.Forms.Button();
            this.FuncoesAuxiliares = new System.Windows.Forms.GroupBox();
            this.RelGerencial = new System.Windows.Forms.Button();
            this.CFeCompleto = new System.Windows.Forms.Button();
            this.UltimasInformacoesSAT = new System.Windows.Forms.Button();
            this.ConfigurarFM = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PainelRetornoSefaz = new System.Windows.Forms.TextBox();
            this.ConsultarErroSefaz = new System.Windows.Forms.Button();
            this.CampoConsultaRejeicao = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PainelJsonComando = new System.Windows.Forms.TextBox();
            this.Sair = new System.Windows.Forms.Button();
            this.AjudaAPI = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.PainelSaisadeComando = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Limpar = new System.Windows.Forms.Button();
            this.Limpar02 = new System.Windows.Forms.Button();
            this.closed = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.FuncoesVenda.SuspendLayout();
            this.FuncoesAuxiliares.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // FuncoesVenda
            // 
            this.FuncoesVenda.Controls.Add(this.Bematech_Fiscal_FecharNota);
            this.FuncoesVenda.Controls.Add(this.Bematech_Fiscal_CancelarNota);
            this.FuncoesVenda.Controls.Add(this.Bematech_Fiscal_EfetuarPagamento);
            this.FuncoesVenda.Controls.Add(this.Bematech_Fiscal_VenderItem);
            this.FuncoesVenda.Controls.Add(this.Bematech_Fiscal_AbrirNota);
            this.FuncoesVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FuncoesVenda.ForeColor = System.Drawing.Color.Teal;
            this.FuncoesVenda.Location = new System.Drawing.Point(13, 11);
            this.FuncoesVenda.Name = "FuncoesVenda";
            this.FuncoesVenda.Size = new System.Drawing.Size(193, 647);
            this.FuncoesVenda.TabIndex = 0;
            this.FuncoesVenda.TabStop = false;
            this.FuncoesVenda.Text = "Funções de Venda";
            // 
            // Bematech_Fiscal_FecharNota
            // 
            this.Bematech_Fiscal_FecharNota.BackColor = System.Drawing.Color.LightSeaGreen;
            this.Bematech_Fiscal_FecharNota.FlatAppearance.BorderSize = 0;
            this.Bematech_Fiscal_FecharNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bematech_Fiscal_FecharNota.ForeColor = System.Drawing.Color.White;
            this.Bematech_Fiscal_FecharNota.Location = new System.Drawing.Point(31, 403);
            this.Bematech_Fiscal_FecharNota.Name = "Bematech_Fiscal_FecharNota";
            this.Bematech_Fiscal_FecharNota.Size = new System.Drawing.Size(130, 115);
            this.Bematech_Fiscal_FecharNota.TabIndex = 6;
            this.Bematech_Fiscal_FecharNota.Text = "Fechar Nota";
            this.Bematech_Fiscal_FecharNota.UseVisualStyleBackColor = false;
            this.Bematech_Fiscal_FecharNota.Click += new System.EventHandler(this.Bematech_Fiscal_FecharNota_Click);
            // 
            // Bematech_Fiscal_CancelarNota
            // 
            this.Bematech_Fiscal_CancelarNota.BackColor = System.Drawing.Color.LightCoral;
            this.Bematech_Fiscal_CancelarNota.FlatAppearance.BorderSize = 0;
            this.Bematech_Fiscal_CancelarNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bematech_Fiscal_CancelarNota.ForeColor = System.Drawing.Color.White;
            this.Bematech_Fiscal_CancelarNota.Location = new System.Drawing.Point(32, 520);
            this.Bematech_Fiscal_CancelarNota.Name = "Bematech_Fiscal_CancelarNota";
            this.Bematech_Fiscal_CancelarNota.Size = new System.Drawing.Size(130, 115);
            this.Bematech_Fiscal_CancelarNota.TabIndex = 8;
            this.Bematech_Fiscal_CancelarNota.Text = "Cancelar Cupom";
            this.Bematech_Fiscal_CancelarNota.UseVisualStyleBackColor = false;
            this.Bematech_Fiscal_CancelarNota.Click += new System.EventHandler(this.Bematech_Fiscal_CancelarNota_Click);
            // 
            // Bematech_Fiscal_EfetuarPagamento
            // 
            this.Bematech_Fiscal_EfetuarPagamento.BackColor = System.Drawing.Color.LightGray;
            this.Bematech_Fiscal_EfetuarPagamento.FlatAppearance.BorderSize = 0;
            this.Bematech_Fiscal_EfetuarPagamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bematech_Fiscal_EfetuarPagamento.ForeColor = System.Drawing.Color.Teal;
            this.Bematech_Fiscal_EfetuarPagamento.Location = new System.Drawing.Point(31, 277);
            this.Bematech_Fiscal_EfetuarPagamento.Name = "Bematech_Fiscal_EfetuarPagamento";
            this.Bematech_Fiscal_EfetuarPagamento.Size = new System.Drawing.Size(130, 124);
            this.Bematech_Fiscal_EfetuarPagamento.TabIndex = 5;
            this.Bematech_Fiscal_EfetuarPagamento.Text = "Efetua Pgto";
            this.Bematech_Fiscal_EfetuarPagamento.UseVisualStyleBackColor = false;
            this.Bematech_Fiscal_EfetuarPagamento.Click += new System.EventHandler(this.Bematech_Fiscal_EfetuarPagamento_Click);
            // 
            // Bematech_Fiscal_VenderItem
            // 
            this.Bematech_Fiscal_VenderItem.BackColor = System.Drawing.Color.LightGray;
            this.Bematech_Fiscal_VenderItem.FlatAppearance.BorderSize = 0;
            this.Bematech_Fiscal_VenderItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bematech_Fiscal_VenderItem.ForeColor = System.Drawing.Color.Teal;
            this.Bematech_Fiscal_VenderItem.Location = new System.Drawing.Point(31, 151);
            this.Bematech_Fiscal_VenderItem.Name = "Bematech_Fiscal_VenderItem";
            this.Bematech_Fiscal_VenderItem.Size = new System.Drawing.Size(130, 124);
            this.Bematech_Fiscal_VenderItem.TabIndex = 4;
            this.Bematech_Fiscal_VenderItem.Text = "Vende Item";
            this.Bematech_Fiscal_VenderItem.UseVisualStyleBackColor = false;
            this.Bematech_Fiscal_VenderItem.Click += new System.EventHandler(this.Bematech_Fiscal_VenderItem_Click);
            // 
            // Bematech_Fiscal_AbrirNota
            // 
            this.Bematech_Fiscal_AbrirNota.BackColor = System.Drawing.Color.LightGray;
            this.Bematech_Fiscal_AbrirNota.FlatAppearance.BorderSize = 0;
            this.Bematech_Fiscal_AbrirNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bematech_Fiscal_AbrirNota.ForeColor = System.Drawing.Color.Teal;
            this.Bematech_Fiscal_AbrirNota.Location = new System.Drawing.Point(31, 25);
            this.Bematech_Fiscal_AbrirNota.Name = "Bematech_Fiscal_AbrirNota";
            this.Bematech_Fiscal_AbrirNota.Size = new System.Drawing.Size(130, 124);
            this.Bematech_Fiscal_AbrirNota.TabIndex = 3;
            this.Bematech_Fiscal_AbrirNota.Text = "AbrirNota";
            this.Bematech_Fiscal_AbrirNota.UseVisualStyleBackColor = false;
            this.Bematech_Fiscal_AbrirNota.Click += new System.EventHandler(this.AbreCupom_Click);
            // 
            // FuncoesAuxiliares
            // 
            this.FuncoesAuxiliares.Controls.Add(this.RelGerencial);
            this.FuncoesAuxiliares.Controls.Add(this.CFeCompleto);
            this.FuncoesAuxiliares.Controls.Add(this.UltimasInformacoesSAT);
            this.FuncoesAuxiliares.Controls.Add(this.ConfigurarFM);
            this.FuncoesAuxiliares.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FuncoesAuxiliares.ForeColor = System.Drawing.Color.Teal;
            this.FuncoesAuxiliares.Location = new System.Drawing.Point(799, 12);
            this.FuncoesAuxiliares.Name = "FuncoesAuxiliares";
            this.FuncoesAuxiliares.Size = new System.Drawing.Size(221, 206);
            this.FuncoesAuxiliares.TabIndex = 1;
            this.FuncoesAuxiliares.TabStop = false;
            this.FuncoesAuxiliares.Text = "Funções Auxiliares";
            // 
            // RelGerencial
            // 
            this.RelGerencial.BackColor = System.Drawing.Color.LightGray;
            this.RelGerencial.FlatAppearance.BorderSize = 0;
            this.RelGerencial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RelGerencial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.RelGerencial.Location = new System.Drawing.Point(112, 110);
            this.RelGerencial.Name = "RelGerencial";
            this.RelGerencial.Size = new System.Drawing.Size(86, 87);
            this.RelGerencial.TabIndex = 11;
            this.RelGerencial.Text = "Relatório Gerencial";
            this.RelGerencial.UseVisualStyleBackColor = false;
            // 
            // CFeCompleto
            // 
            this.CFeCompleto.BackColor = System.Drawing.Color.LightGray;
            this.CFeCompleto.FlatAppearance.BorderSize = 0;
            this.CFeCompleto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CFeCompleto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CFeCompleto.Location = new System.Drawing.Point(24, 110);
            this.CFeCompleto.Name = "CFeCompleto";
            this.CFeCompleto.Size = new System.Drawing.Size(86, 87);
            this.CFeCompleto.TabIndex = 10;
            this.CFeCompleto.Text = "CFe Completo";
            this.CFeCompleto.UseVisualStyleBackColor = false;
            this.CFeCompleto.Click += new System.EventHandler(this.CFeCompleto_Click);
            // 
            // UltimasInformacoesSAT
            // 
            this.UltimasInformacoesSAT.BackColor = System.Drawing.Color.LightGray;
            this.UltimasInformacoesSAT.FlatAppearance.BorderSize = 0;
            this.UltimasInformacoesSAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UltimasInformacoesSAT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.UltimasInformacoesSAT.Location = new System.Drawing.Point(112, 21);
            this.UltimasInformacoesSAT.Name = "UltimasInformacoesSAT";
            this.UltimasInformacoesSAT.Size = new System.Drawing.Size(86, 87);
            this.UltimasInformacoesSAT.TabIndex = 9;
            this.UltimasInformacoesSAT.Text = "Ultimas Informações SAT";
            this.UltimasInformacoesSAT.UseVisualStyleBackColor = false;
            // 
            // ConfigurarFM
            // 
            this.ConfigurarFM.BackColor = System.Drawing.Color.LightGray;
            this.ConfigurarFM.FlatAppearance.BorderSize = 0;
            this.ConfigurarFM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfigurarFM.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ConfigurarFM.Location = new System.Drawing.Point(23, 21);
            this.ConfigurarFM.Name = "ConfigurarFM";
            this.ConfigurarFM.Size = new System.Drawing.Size(86, 87);
            this.ConfigurarFM.TabIndex = 7;
            this.ConfigurarFM.Text = "Configurar FM";
            this.ConfigurarFM.UseVisualStyleBackColor = false;
            this.ConfigurarFM.Click += new System.EventHandler(this.ConfigurarFM_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.PainelRetornoSefaz);
            this.groupBox1.Controls.Add(this.ConsultarErroSefaz);
            this.groupBox1.Controls.Add(this.CampoConsultaRejeicao);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.IndianRed;
            this.groupBox1.Location = new System.Drawing.Point(803, 241);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(221, 209);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rejeição da Sefaz";
            // 
            // PainelRetornoSefaz
            // 
            this.PainelRetornoSefaz.BackColor = System.Drawing.SystemColors.Control;
            this.PainelRetornoSefaz.Location = new System.Drawing.Point(6, 96);
            this.PainelRetornoSefaz.Multiline = true;
            this.PainelRetornoSefaz.Name = "PainelRetornoSefaz";
            this.PainelRetornoSefaz.Size = new System.Drawing.Size(209, 107);
            this.PainelRetornoSefaz.TabIndex = 16;
            this.PainelRetornoSefaz.TextChanged += new System.EventHandler(this.PainelRetornoSefaz_TextChanged);
            // 
            // ConsultarErroSefaz
            // 
            this.ConsultarErroSefaz.BackColor = System.Drawing.Color.LightGray;
            this.ConsultarErroSefaz.FlatAppearance.BorderSize = 0;
            this.ConsultarErroSefaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConsultarErroSefaz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ConsultarErroSefaz.Location = new System.Drawing.Point(146, 20);
            this.ConsultarErroSefaz.Name = "ConsultarErroSefaz";
            this.ConsultarErroSefaz.Size = new System.Drawing.Size(69, 70);
            this.ConsultarErroSefaz.TabIndex = 12;
            this.ConsultarErroSefaz.Text = "Consultar";
            this.ConsultarErroSefaz.UseVisualStyleBackColor = false;
            this.ConsultarErroSefaz.Click += new System.EventHandler(this.ConsultarErroSefaz_Click);
            // 
            // CampoConsultaRejeicao
            // 
            this.CampoConsultaRejeicao.Location = new System.Drawing.Point(7, 47);
            this.CampoConsultaRejeicao.Name = "CampoConsultaRejeicao";
            this.CampoConsultaRejeicao.Size = new System.Drawing.Size(133, 21);
            this.CampoConsultaRejeicao.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.PainelJsonComando);
            this.groupBox2.Controls.Add(this.Sair);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Teal;
            this.groupBox2.Location = new System.Drawing.Point(228, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(565, 217);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Json do Comando";
            // 
            // PainelJsonComando
            // 
            this.PainelJsonComando.Location = new System.Drawing.Point(6, 20);
            this.PainelJsonComando.Multiline = true;
            this.PainelJsonComando.Name = "PainelJsonComando";
            this.PainelJsonComando.Size = new System.Drawing.Size(553, 191);
            this.PainelJsonComando.TabIndex = 14;
            this.PainelJsonComando.TextChanged += new System.EventHandler(this.PainelJsonComando_TextChanged);
            // 
            // Sair
            // 
            this.Sair.BackColor = System.Drawing.Color.LightGray;
            this.Sair.FlatAppearance.BorderSize = 0;
            this.Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Sair.Location = new System.Drawing.Point(248, 444);
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(75, 32);
            this.Sair.TabIndex = 13;
            this.Sair.Text = "SAIR";
            this.Sair.UseVisualStyleBackColor = false;
            // 
            // AjudaAPI
            // 
            this.AjudaAPI.BackColor = System.Drawing.Color.Silver;
            this.AjudaAPI.FlatAppearance.BorderSize = 0;
            this.AjudaAPI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AjudaAPI.ForeColor = System.Drawing.Color.DimGray;
            this.AjudaAPI.Location = new System.Drawing.Point(286, 575);
            this.AjudaAPI.Name = "AjudaAPI";
            this.AjudaAPI.Size = new System.Drawing.Size(230, 92);
            this.AjudaAPI.TabIndex = 14;
            this.AjudaAPI.Text = "Ajuda da ?";
            this.AjudaAPI.UseVisualStyleBackColor = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 671);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.statusStrip1.Size = new System.Drawing.Size(1032, 22);
            this.statusStrip1.TabIndex = 15;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(116, 17);
            this.toolStripStatusLabel1.Text = "Atual em 17/04/2017";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(110, 17);
            this.toolStripStatusLabel2.Text = "Fiscal Manager SAT";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(166, 17);
            this.toolStripStatusLabel3.Text = "BSP - Bematech @ Alessandro";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.PainelSaisadeComando);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Teal;
            this.groupBox3.Location = new System.Drawing.Point(228, 259);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(568, 282);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Saida de Comando";
            // 
            // PainelSaisadeComando
            // 
            this.PainelSaisadeComando.Location = new System.Drawing.Point(6, 20);
            this.PainelSaisadeComando.Multiline = true;
            this.PainelSaisadeComando.Name = "PainelSaisadeComando";
            this.PainelSaisadeComando.Size = new System.Drawing.Size(553, 256);
            this.PainelSaisadeComando.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.Location = new System.Drawing.Point(248, 444);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 32);
            this.button1.TabIndex = 13;
            this.button1.Text = "SAIR";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // Limpar
            // 
            this.Limpar.BackColor = System.Drawing.Color.LightGray;
            this.Limpar.Location = new System.Drawing.Point(234, 231);
            this.Limpar.Name = "Limpar";
            this.Limpar.Size = new System.Drawing.Size(553, 24);
            this.Limpar.TabIndex = 16;
            this.Limpar.Text = "Limpar";
            this.Limpar.UseVisualStyleBackColor = false;
            this.Limpar.Click += new System.EventHandler(this.Limpar_Click);
            // 
            // Limpar02
            // 
            this.Limpar02.BackColor = System.Drawing.Color.LightGray;
            this.Limpar02.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Limpar02.Location = new System.Drawing.Point(234, 543);
            this.Limpar02.Name = "Limpar02";
            this.Limpar02.Size = new System.Drawing.Size(559, 24);
            this.Limpar02.TabIndex = 17;
            this.Limpar02.Text = "Limpar";
            this.Limpar02.UseVisualStyleBackColor = false;
            this.Limpar02.Click += new System.EventHandler(this.Limpar02_Click);
            // 
            // closed
            // 
            this.closed.BackColor = System.Drawing.Color.Gray;
            this.closed.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.closed.Location = new System.Drawing.Point(962, 610);
            this.closed.Name = "closed";
            this.closed.Size = new System.Drawing.Size(62, 57);
            this.closed.TabIndex = 18;
            this.closed.Text = "SAIR";
            this.closed.UseVisualStyleBackColor = false;
            this.closed.Click += new System.EventHandler(this.closed_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.logobematech;
            this.pictureBox2.Location = new System.Drawing.Point(850, 475);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(115, 92);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WindowsFormsApplication2.Properties.Resources.LogoAPI_192X80;
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = global::WindowsFormsApplication2.Properties.Resources.LogoAPI_192X80;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(569, 572);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(184, 95);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1032, 693);
            this.Controls.Add(this.closed);
            this.Controls.Add(this.Limpar02);
            this.Controls.Add(this.Limpar);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.AjudaAPI);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.FuncoesAuxiliares);
            this.Controls.Add(this.FuncoesVenda);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Principal";
            this.Text = "Teste SAT - OneAPI";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.FuncoesVenda.ResumeLayout(false);
            this.FuncoesAuxiliares.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox FuncoesVenda;
        private System.Windows.Forms.GroupBox FuncoesAuxiliares;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Bematech_Fiscal_AbrirNota;
        private System.Windows.Forms.Button Bematech_Fiscal_VenderItem;
        private System.Windows.Forms.Button Bematech_Fiscal_FecharNota;
        private System.Windows.Forms.Button Bematech_Fiscal_EfetuarPagamento;
        private System.Windows.Forms.Button ConfigurarFM;
        private System.Windows.Forms.Button Bematech_Fiscal_CancelarNota;
        private System.Windows.Forms.Button UltimasInformacoesSAT;
        private System.Windows.Forms.Button RelGerencial;
        private System.Windows.Forms.Button CFeCompleto;
        private System.Windows.Forms.Button ConsultarErroSefaz;
        private System.Windows.Forms.TextBox CampoConsultaRejeicao;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Sair;
        private System.Windows.Forms.Button AjudaAPI;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox PainelJsonComando;
        private System.Windows.Forms.TextBox PainelSaisadeComando;
        private System.Windows.Forms.Button Limpar;
        private System.Windows.Forms.Button Limpar02;
        private System.Windows.Forms.Button closed;
        private System.Windows.Forms.TextBox PainelRetornoSefaz;
    }
}

