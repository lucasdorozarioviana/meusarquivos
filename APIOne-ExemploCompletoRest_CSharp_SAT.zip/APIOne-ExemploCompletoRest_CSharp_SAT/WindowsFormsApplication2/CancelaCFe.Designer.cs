﻿namespace WindowsFormsApplication2
{
    partial class CancelaCFe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CancelaCFe));
            this.PainelCancelarNota = new System.Windows.Forms.TextBox();
            this.Bematech_Fiscal_CancelarNota = new System.Windows.Forms.Button();
            this.BotaoSair = new System.Windows.Forms.Button();
            this.PainelRetornoCancelarNota = new System.Windows.Forms.TextBox();
            this.Box_PainelCancelarNota = new System.Windows.Forms.GroupBox();
            this.LimparCancela01 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LimparCancela02 = new System.Windows.Forms.Button();
            this.Box_PainelCancelarNota.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PainelCancelarNota
            // 
            this.PainelCancelarNota.Location = new System.Drawing.Point(6, 19);
            this.PainelCancelarNota.Multiline = true;
            this.PainelCancelarNota.Name = "PainelCancelarNota";
            this.PainelCancelarNota.Size = new System.Drawing.Size(502, 196);
            this.PainelCancelarNota.TabIndex = 15;
            this.PainelCancelarNota.Text = resources.GetString("PainelCancelarNota.Text");
            // 
            // Bematech_Fiscal_CancelarNota
            // 
            this.Bematech_Fiscal_CancelarNota.BackColor = System.Drawing.Color.Tomato;
            this.Bematech_Fiscal_CancelarNota.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Bematech_Fiscal_CancelarNota.Location = new System.Drawing.Point(388, 240);
            this.Bematech_Fiscal_CancelarNota.Name = "Bematech_Fiscal_CancelarNota";
            this.Bematech_Fiscal_CancelarNota.Size = new System.Drawing.Size(132, 47);
            this.Bematech_Fiscal_CancelarNota.TabIndex = 16;
            this.Bematech_Fiscal_CancelarNota.Text = "Cancelar Nota";
            this.Bematech_Fiscal_CancelarNota.UseVisualStyleBackColor = false;
            this.Bematech_Fiscal_CancelarNota.Click += new System.EventHandler(this.Bematech_Fiscal_CancelarNota_Click);
            // 
            // BotaoSair
            // 
            this.BotaoSair.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BotaoSair.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BotaoSair.Location = new System.Drawing.Point(460, 486);
            this.BotaoSair.Name = "BotaoSair";
            this.BotaoSair.Size = new System.Drawing.Size(60, 44);
            this.BotaoSair.TabIndex = 17;
            this.BotaoSair.Text = "SAIR";
            this.BotaoSair.UseVisualStyleBackColor = false;
            this.BotaoSair.Click += new System.EventHandler(this.BotaoSair_Click);
            // 
            // PainelRetornoCancelarNota
            // 
            this.PainelRetornoCancelarNota.Location = new System.Drawing.Point(6, 24);
            this.PainelRetornoCancelarNota.Multiline = true;
            this.PainelRetornoCancelarNota.Name = "PainelRetornoCancelarNota";
            this.PainelRetornoCancelarNota.Size = new System.Drawing.Size(502, 152);
            this.PainelRetornoCancelarNota.TabIndex = 18;
            // 
            // Box_PainelCancelarNota
            // 
            this.Box_PainelCancelarNota.Controls.Add(this.PainelCancelarNota);
            this.Box_PainelCancelarNota.Location = new System.Drawing.Point(12, 2);
            this.Box_PainelCancelarNota.Name = "Box_PainelCancelarNota";
            this.Box_PainelCancelarNota.Size = new System.Drawing.Size(524, 232);
            this.Box_PainelCancelarNota.TabIndex = 19;
            this.Box_PainelCancelarNota.TabStop = false;
            this.Box_PainelCancelarNota.Text = "Painel Cancelar Nota";
            // 
            // LimparCancela01
            // 
            this.LimparCancela01.BackColor = System.Drawing.Color.DarkGray;
            this.LimparCancela01.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LimparCancela01.Location = new System.Drawing.Point(333, 240);
            this.LimparCancela01.Name = "LimparCancela01";
            this.LimparCancela01.Size = new System.Drawing.Size(54, 47);
            this.LimparCancela01.TabIndex = 20;
            this.LimparCancela01.Text = "Limpar";
            this.LimparCancela01.UseVisualStyleBackColor = false;
            this.LimparCancela01.Click += new System.EventHandler(this.LimparCancela01_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.PainelRetornoCancelarNota);
            this.groupBox1.Location = new System.Drawing.Point(12, 293);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(524, 187);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Painel Retorno Cancelar Nota";
            // 
            // LimparCancela02
            // 
            this.LimparCancela02.BackColor = System.Drawing.Color.DarkGray;
            this.LimparCancela02.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LimparCancela02.Location = new System.Drawing.Point(404, 486);
            this.LimparCancela02.Name = "LimparCancela02";
            this.LimparCancela02.Size = new System.Drawing.Size(54, 44);
            this.LimparCancela02.TabIndex = 21;
            this.LimparCancela02.Text = "Limpar";
            this.LimparCancela02.UseVisualStyleBackColor = false;
            this.LimparCancela02.Click += new System.EventHandler(this.LimparCancela02_Click);
            // 
            // CancelaCFe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(552, 534);
            this.Controls.Add(this.LimparCancela02);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.LimparCancela01);
            this.Controls.Add(this.Box_PainelCancelarNota);
            this.Controls.Add(this.BotaoSair);
            this.Controls.Add(this.Bematech_Fiscal_CancelarNota);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CancelaCFe";
            this.Text = "CancelaCFe";
            this.Box_PainelCancelarNota.ResumeLayout(false);
            this.Box_PainelCancelarNota.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox PainelCancelarNota;
        private System.Windows.Forms.Button Bematech_Fiscal_CancelarNota;
        private System.Windows.Forms.Button BotaoSair;
        private System.Windows.Forms.TextBox PainelRetornoCancelarNota;
        private System.Windows.Forms.GroupBox Box_PainelCancelarNota;
        private System.Windows.Forms.Button LimparCancela01;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button LimparCancela02;
    }
}