#!/usr/bin/env python
# -*- coding: latin-1 -*-







import ctypes
import marshal
import os
import datetime
from os import listdir
from ctypes import * 
from sys import * 
from random import randint

path = "./CuponsGerados/"
pathResult = "./Resultado/"

directory = os.listdir(path)

contadorSucessoStatus = 0
contadorFalhaStatus = 0

contadorSucessoCupom = 0
contadorFalhaCupom = 0
contadorVendas = 1
contadorStatus = 1

contador = 0

for contador in range(0, 9):

	for files in directory:

		file = open(path + files,'r')

		xmlFile = file.read()

		# CALLING DLL
		#library = ctypes.WinDLL("C:\Windows\System32\BemaSAT.dll") # chamando a DLL
		library = CDLL("libbemasat.so")

		numsessao = c_int()


		numsessao = randint(000000,999999)
		print "\n\n\n\n -------------------------------------------------------------\n\n\n\n"
		print "ARQUIVO: " + files

		#Realizar venda
		print "\n Realizar venda Numero#: "+ str(contadorVendas) + " \n" 
		ret = library.EnviarDadosVenda(numsessao,"bema1234",xmlFile)
		print ret
		retorno = c_char_p(ret)
		print retorno.value
		array = retorno.value.split('|')
		print "RETORNO EMISSAO CUPOM: " + array[1] + "|" + array[2] + "|" + array[3]
		print "\n\n\n\n -------------------------------------------------------------\n\n\n\n"
		contadorVendas = contadorVendas+1

		if array[1] == "06000":
			print "SUCESSO\n"
			contadorSucessoCupom = contadorSucessoCupom + 1
			print "\n\nRealizar Venda - Sucessos: "+ str(contadorSucessoCupom)
			file1 = open(pathResult + "SUCESSO_CUPOM.txt",'a')
			file1.write(files + " - "+ str(datetime.datetime.now()) +  ",\n")
		else:
			print "FALHA\n"
			contadorFalhaCupom = contadorFalhaCupom + 1
			print "\n\nRealizar Venda - falhas: "+ str(contadorFalhaCupom)
			file1 = open(pathResult + "FALHAS_CUPOM.txt",'a')
			file1.write(files + " - "+ str(datetime.datetime.now()) + ",\n")


		#Consultar Status Operacional
			numsessao = c_int()


		numsessao = randint(000000,999999)
		print "\n\n\n\n -------------------------------------------------------------\n\n\n\n"
		
		print "\n Consulta Status Numero#: "+ str(contadorStatus) + " \n" 
		ret = library.ConsultarStatusOperacional(numsessao,"bema1234")
		print ret
		retorno = c_char_p(ret)
		print retorno.value
		array = retorno.value.split('|')
		print "RETORNO CONSULTA STATUS OPERACIONAL: " + array[1] + "|" + array[2] + "|" + array[3]
		print "\n\n\n\n -------------------------------------------------------------\n\n\n\n"
		

		if array[1] == "10000":
			print "SUCESSO\n"
			contadorSucessoStatus = contadorSucessoStatus + 1
			print "\n\nConsultar status Operacional - Sucessos: "+ str(contadorSucessoStatus)
			file1 = open(pathResult + "SUCESSO_STATUS.txt",'a')
			file1.write("\n Consulta Status Numero#: "+ str(contadorStatus) + " - " + str(datetime.datetime.now()) + ",\n")
			contadorStatus = contadorStatus + 1
		else:
			print "FALHA\n"
			contadorFalhaStatus = contadorFalhaStatus + 1
			print "\n\nConsultar Status Operacional - Falhas: "+ str(contadorFalhaStatus)
			file1 = open(pathResult + "FALHAS_STATUS.txt",'a')
			file1.write("\n Consulta Status Numero#: "+ str(contadorStatus) + " - " +  str(datetime.datetime.now()) + ",\n")
			contadorStatus = contadorStatus + 1



		
print "\n\nTOTAL SUCESSOS: " + str(contadorSucessoCupom+contadorSucessoStatus) + "\n"
print "TOTAL FALHAS: " + str(contadorFalhaCupom+contadorFalhaStatus) + "\n"

#Atualizado por Lucas Viana - BSP
