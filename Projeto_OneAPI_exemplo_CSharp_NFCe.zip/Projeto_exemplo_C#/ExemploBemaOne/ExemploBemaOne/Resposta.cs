﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Exemplo de uso da BemaOne.DLL - BemaOne API
// Autores: Anderson Lima, Daniel Lima, Adroaldo Martins, Frederico Schneider
// Data: 27 janeiro 2017
namespace ExemploBemaOne
{
    public class Resposta
    {
        public string sucesso { get; set; }
        public string numeroSessao { get; set; }
    }
}
