﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Exemplo de uso da BemaOne.DLL - BemaOne API
// Autores: Anderson Lima, Daniel Lima, Adroaldo Martins, Frederico Schneider
// Data: 27 janeiro 2017
namespace ExemploBemaOne
{
    static class Constantes
    {
        public const string URL = "http://localhost:9999/api/v1";
        public const string DOCUMENTO_CUPOM = "/documento/cupom";
        public const string DOCUMENTO = "/documento";
        public const string DOCUMENTO_VENDER_ITEM = "/item";
        public const string DOCUMENTO_PAGAMENTO_CUPOM = "/pagamento";
        public const string SISTEMA_INFORMACOES = "/sistema";

        public const string IMPRESSORA_STATUS = "/impressora";
        public const string IMPRESSORA_GUILHOTINA = "/impressora/guilhotina";
        public const string IMPRESSORA_DOCUMENTO = "/impressora/documento";

        public const string MEDIA_TYPE_VND_BNC_JSON = "application/vnd+bematech.bnc+json";
        public const string MEDIA_TYPE_JSON = "application/json";
        public const string MEDIA_TYPE_PDF = "application/pdf";

    }
}
