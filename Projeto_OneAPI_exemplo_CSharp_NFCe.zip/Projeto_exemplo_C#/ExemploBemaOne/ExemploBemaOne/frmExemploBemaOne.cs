﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Net;
using System.IO;

// Exemplo de uso da BemaOne.DLL - BemaOne API
// Autores: Anderson Lima, Daniel Lima, Adroaldo Martins, Frederico Schneider
// Data: 27 janeiro 2017
namespace ExemploBemaOne
{
    public partial class frmExemploBemaOne : Form
    {
        string sessao = String.Empty;

        public frmExemploBemaOne()
        {
            InitializeComponent();
        }

        #region Eventos
        private void btAbrir_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            abreNota();
        }

        private void btVender_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            vendeItem("1.00");
        }

        private void btPagar_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            pagarNota();
        }

        private void btFechar_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            fecharNota();
        }

        private void btEstornar_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            estornarNota();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            cancelarNota();
        }

        private void btStatus_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            statusImpressora();
        }

        private void btInformacaoSistema_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            informacaoSistema();
        }

        private void btNotaErro_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            abreNota();
            vendeItem("0.00");
            pagarNota();
            fecharNota();
        }

        private void btEnviar_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            enviarTextoLivre();
        }

        private void btConsultarNota_Click(object sender, EventArgs e)
        {
            rtbEnvio.Clear();
            rtbRetorno.Clear();
            consultarNota();
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Função que cria um arquivo PDF a partir de uma string de um PDF na base64.
        /// O arquivo é criado na pasta da aplicação.
        /// </summary>
        /// <param name="base64Encoded">String na base64</param>
        /// <param name="nomeArquivo">Nome do Arquivo</param>
        private static void base64ToPdf(string base64Encoded, string nomeArquivo)
        {
            try
            {
                byte[] bytes = Convert.FromBase64String(base64Encoded);
                System.IO.FileStream stream = new System.IO.FileStream(nomeArquivo, System.IO.FileMode.CreateNew);
                System.IO.BinaryWriter writer = new System.IO.BinaryWriter(stream);
                writer.Write(bytes, 0, bytes.Length);
                writer.Close();
                MessageBox.Show("O arquivo (" + nomeArquivo + ") foi salvo na pasta:\n" + Application.StartupPath, "Arquivo salvo!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro na gravação do arquivo.\n" + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// Função para converter uma string em uma string base64.
        /// </summary>
        /// <param name="texto">String com o texto a ser convertido para a base64</param>
        /// <returns>string</returns>
        public static string base64Encode(string texto)
        {
            var textoBytes = System.Text.Encoding.UTF8.GetBytes(texto);
            return System.Convert.ToBase64String(textoBytes);
        }
        /// <summary>
        /// Função que abrir a nota.
        /// </summary>
        private void abreNota()
        {
            //Formatação da data para envio no JSON
            DateTime data = new DateTime();
            data = DateTime.Now;
            string dataFormatada = String.Format("{0:yyyy-MM-ddTHH:mm:sszzz}", data);

            rtbEnvio.Text = "{\n"
                + "	\"versao\": \"3.10\",\n"
                + "	\"configuracao\": {\n"
                + "		\"imprimir\": true,\n"
                + "		\"email\": true\n"
                + "	},\n"
                + "	\"identificacao\": {\n"
                + "		\"cuf\": \"41\",\n"
                + "		\"cnf\": \"00005000\",\n"
                + "		\"natOp\": \"VENDA\",\n"
                + "		\"indPag\": 0,\n"
                + "		\"mod\": \"65\",\n"
                + "		\"serie\": \"" + tbSerie.Text + "\",\n"
                + "		\"nnf\": \"" + tbNumero.Text + "\",\n"
                + "		\"dhEmi\": \"" + dataFormatada + "\",\n"
                + "		\"tpNF\": \"1\",\n"
                + "		\"idDest\": 1,\n"
                + "		\"tpImp\": 4,\n"
                + "		\"tpEmis\": 1,\n"
                + "		\"cdv\": 8,\n"
                + "		\"tpAmb\": 2,\n"
                + "		\"finNFe\": 1,\n"
                + "		\"indFinal\": 1,\n"
                + "		\"indPres\": 1,\n"
                + "		\"procEmi\": 0,\n"
                + "		\"verProc\": \"1.0.0.0\",\n"
                + "		\"cMunFG\": \"4106902\"\n"
                + "	},\n"
                + "	\"emitente\": {\n"
                + "		\"cnpj\": \"" + tbCnpj.Text + "\",\n"
                + "		\"endereco\": {\n"
                + "			\"nro\": \"0\",\n"
                + "			\"uf\": \"PR\",\n"
                + "			\"cep\": \"81320400\",\n"
                + "			\"fone\": \"4184848484\",\n"
                + "			\"xBairro\": \"CABRAL\",\n"
                + "			\"xLgr\": \"AV Teste\",\n"
                + "			\"cMun\": \"4106902\",\n"
                + "			\"cPais\": \"1058\",\n"
                + "			\"xPais\": \"BRASIL\",\n"
                + "			\"xMun\": \"Curltiba\"\n"
                + "		},\n"
                + "		\"ie\": \"1018146530\",\n"
                + "		\"crt\": 3,\n"
                + "		\"xNome\": \"BEMATECH SA\",\n"
                + "		\"xFant\": \"BEMATECH\"\n"
                + "	},\n"
                + "	\"destinatario\": {\n"
                + "		\"cpf\": \"65564179048\",\n"
                + "		\"endereco\": {\n"
                + "			\"nro\": \"842\",\n"
                + "			\"uf\": \"PR\",\n"
                + "			\"cep\": \"80020320\",\n"
                + "			\"fone\": \"41927598874\",\n"
                + "			\"xBairro\": \"Centro\",\n"
                + "			\"xLgr\": \"Marechal Deodoro\",\n"
                + "			\"cMun\": \"4106902\",\n"
                + "			\"cPais\": \"1058\",\n"
                + "			\"xPais\": \"Brasil\",\n"
                + "			\"xMun\": \"Curltiba\"\n"
                + "		},\n"
                + "		\"indIEDest\": 9,\n"
                + "		\"email\": \"teste@teste.com\",\n"
                + "		\"xNome\": \"NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL \"\n"
                + "	}\n"
                + "}";

            if (rbDll.Checked)
            {
                //Abertura da nota utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_AbrirNota(rtbEnvio.Text);
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                var urlPost = Constantes.URL + Constantes.DOCUMENTO_CUPOM;

                MyWebRequest myRequest = new MyWebRequest();
                try
                {
                    var respostaJson = myRequest.postJsonData(urlPost, rtbEnvio.Text, Constantes.MEDIA_TYPE_JSON, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = respostaJson;
                }
                catch (WebException wex)
                {
                    //Quando o servidor retorna o erro 500 é necessário tratar a resposta pela excessão.
                    var pageContent = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd();
                    rtbRetorno.Text = pageContent;
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
            //Deserializa o JSON de retorno em um objeto (Resposta) para pegar o número de sessão da resposta
            if (rtbRetorno.Text.Contains("true"))
            {
                Resposta resp = new JavaScriptSerializer().Deserialize<Resposta>(rtbRetorno.Text);
                sessao = resp.numeroSessao;
            }
        }
        /// <summary>
        /// Função que vende item.
        /// </summary>
        /// <param name="valorItem"></param>
        private void vendeItem(string valorItem)
        {
            rtbEnvio.Text = "{\n"
                + "  \"produto\": {\n"
                + "		\"cean\": \"7897238304177\",\n"
                + "		\"ncm\": \"85258029\",\n"
                + "		\"cfop\": \"5101\",\n"
                + "		\"indTot\": 1,\n"
                + "		\"vUnCom\": 1.000,\n"
                + "		\"uTrib\": \"UN\",\n"
                + "		\"vUnTrib\": \"1.000\",\n"
                + "		\"cProd\": \"85258029901234\",\n"
                + "		\"xProd\": \"Produto Teste\",\n"
                + "		\"uCom\": \"UN\",\n"
                + "		\"qTrib\": 1.000,\n"
                + "		\"qCom\": \"1.000\",\n"
                + "		\"vProd\": " + valorItem + "\n"
                + "	},\n"
                + "	\"imposto\": {\n"
                + "		\"icms\": {\n"
                + "			\"icms00\": {\n"
                + "				\"orig\": 1,\n"
                + "				\"cst\": \"00\","
                + "				\"modBC\": 3,\n"
                + "				\"vbc\": 1.00,\n"
                + "				\"picms\": 1.01,\n"
                + "				\"vicms\": 0.01\n"
                + "	  		}\n"
                + "		},\n"
                + "		\"vTotTrib\": 0.00\n"
                + "	}\n"
                + "}";

            if (rbDll.Checked)
            {
                //Venda de item utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_VenderItem(rtbEnvio.Text.ToString());
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                var urlPost = Constantes.URL + Constantes.DOCUMENTO_CUPOM + "/" + sessao + Constantes.DOCUMENTO_VENDER_ITEM;

                MyWebRequest myRequest = new MyWebRequest();
                try
                {
                    var respostaJson = myRequest.postJsonData(urlPost, rtbEnvio.Text, Constantes.MEDIA_TYPE_JSON, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = respostaJson;
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
        }
        /// <summary>
        /// Função que paga a nota.
        /// </summary>
        private void pagarNota()
        {
            rtbEnvio.Text = "{\n"
                + "\"tPag\": 1,\n"
                + "\"vPag\": 1.00\n"
                + "}";

            if (rbDll.Checked)
            {
                //Pagamento da nota utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_EfetuarPagamento(rtbEnvio.Text.ToString());
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                var resposta = String.Empty;
                var urlPost = Constantes.URL + Constantes.DOCUMENTO_CUPOM + "/" + sessao + Constantes.DOCUMENTO_PAGAMENTO_CUPOM;

                MyWebRequest myRequest = new MyWebRequest();
                try
                {
                    var respostaJson = myRequest.postJsonData(urlPost, rtbEnvio.Text, Constantes.MEDIA_TYPE_JSON, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = respostaJson;
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
        }
        /// <summary>
        /// Função que fecha a nota.
        /// </summary>
        private void fecharNota()
        {
            rtbEnvio.Text = "{\n"
                + "  \"total\": {\n"
                + "    \"icmsTotal\": {\n"
                + "      \"vbc\": 1.00,\n"
                + "      \"vicms\": 0.01,\n"
                + "      \"vicmsDeson\": 0.00,\n"
                + "      \"vbcst\": 0.00,\n"
                + "      \"vst\": 0.00,\n"
                + "      \"vii\": 0.00,\n"
                + "      \"vipi\": 0.00,\n"
                + "      \"vpis\": 0.00,\n"
                + "      \"vcofins\": 0.00,\n"
                + "      \"vnf\": 1.00,\n"
                + "      \"vTotTrib\": 0.00,\n"
                + "      \"vDesc\": 0.00,\n"
                + "      \"vProd\": 1.00,\n"
                + "      \"vOutro\": 0.00,\n"
                + "      \"vSeg\": 0.00,\n"
                + "      \"vFrete\": 0.00\n"
                + "    }\n"
                + "  },\n"
                + "  \"informacaoAdicional\": {\n"
                + "    \"infCpl\": \"COO:000328 | CCF:000209 | Sequência 004 - Nota com Cliente\",\n"
                + "    \"observacoesContribuintes\": [\n"
                + "      {\n"
                + "        \"xTexto\": \"0.00\",\n"
                + "        \"xCampo\": \"Troco\"\n"
                + "      }\n"
                + "    ]\n"
                + "  }\n"
                + "}";

            if (rbDll.Checked)
            {
                //Fechamento da nota utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_FecharNota(rtbEnvio.Text.ToString());
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                var resposta = String.Empty;
                var urlPost = Constantes.URL + Constantes.DOCUMENTO_CUPOM + "/" + sessao;

                MyWebRequest myRequest = new MyWebRequest();
                try
                {
                    var respostaJson = myRequest.postJsonData(urlPost, rtbEnvio.Text, Constantes.MEDIA_TYPE_JSON, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = respostaJson;
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
        }
        /// <summary>
        /// Função que cancela a nota fechada.
        /// </summary>
        private void cancelarNota()
        {
            DateTime data = new DateTime();
            data = DateTime.Now;

            string dataFormatada = String.Format("{0:yyyy-MM-ddTHH:mm:sszzz}", data);

            rtbEnvio.Text = "{\n"
                                + "\"id\": \"" + tbCancelarChave.Text + "\",\n"
                                + "\"xJust\": \"Cancelado pelo Desenvolvedor\",\n"
                                + "\"dhEvento\": \"" + dataFormatada + "\"\n"
                            + "}";



            if (rbDll.Checked)
            {
                //Cancelamento da nota utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_CancelarNota(rtbEnvio.Text.ToString());
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                var resposta = String.Empty;
                var urlPost = Constantes.URL + Constantes.DOCUMENTO + "/" + tbCancelarChave.Text;

                MyWebRequest myRequest = new MyWebRequest();
                try
                {
                    var respostaJson = myRequest.postJsonData(urlPost, rtbEnvio.Text, Constantes.MEDIA_TYPE_VND_BNC_JSON, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = respostaJson;
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }

        }
        /// <summary>
        /// Função que retorna o status da impressora.
        /// </summary>
        private void statusImpressora()
        {
            if (rbDll.Checked)
            {
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_ObterStatusImpressora();
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                MyWebRequest myRequest = new MyWebRequest();

                try
                {
                    //Verifica estado da impressora utilizando a DLL BemaOne32.dll
                    var status = myRequest.getJson(Constantes.URL + Constantes.IMPRESSORA_STATUS, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = status;
                    Console.WriteLine(status);
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
        }
        /// <summary>
        /// Função que retorna as informações do sistema.
        /// </summary>
        private void informacaoSistema()
        {
            if (rbDll.Checked)
            {
                //Verifica informações do sistema utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_ObterInformacoesSistema();
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                MyWebRequest myRequest = new MyWebRequest();

                try
                {
                    var status = myRequest.getJson(Constantes.URL + Constantes.SISTEMA_INFORMACOES, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = status;
                    Console.WriteLine(status);
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
        }
        /// <summary>
        /// Função que envia texto livre para a impressora.
        /// </summary>
        private void enviarTextoLivre()
        {
            string guilhotina = String.Empty;

            //comando para enviar no texto livre
            //\x1b\x6d - corte parcial
            if (cbGuilhotina.Checked)
            {
                guilhotina = "\x1b\x6d";
            }


            if (rbDll.Checked)
            {
                //Converte texto para a base64
                string base64Str = base64Encode(rtbTextoLivre.Text + guilhotina);
                rtbEnvio.Text = "{ \"dados\": \"" + base64Str + "\", \"base64\": true }";

                //Impressão de texto livre utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_ImprimirTextoLivre(rtbEnvio.Text.ToString());
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                string texto = rtbTextoLivre.Text + guilhotina;

                var urlPost = Constantes.URL + Constantes.IMPRESSORA_DOCUMENTO;

                MyWebRequest myRequest = new MyWebRequest();

                try
                {
                    var respostaJson = myRequest.postJsonData(urlPost, texto, Constantes.MEDIA_TYPE_JSON, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = respostaJson;
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
        }
        /// <summary>
        /// Função que consulta nota.
        /// A consulta pode ser realizada por Chave de Acesso (ID) ou Serie + Número da nota.
        /// </summary>
        private void consultarNota()
        {
            //Utiliza essa variável para selecionar ContentType do WebRequest
            string mediaType = String.Empty;

            //Seleciona no JSON de envio para a DLL o formato da resposta (PDF ou JSON)
            if (rbPdf.Checked)
            {
                mediaType = Constantes.MEDIA_TYPE_PDF;

                if (!String.IsNullOrEmpty(tbConsultarChave.Text))
                {
                    rtbEnvio.Text = "{\n"
                    + "	\"id\": \"" + tbConsultarChave.Text + "\",\n"
                    + "	\"formato\": \"" + "pdf" + "\"\n"
                    + "}\n";
                }
                else
                {
                    rtbEnvio.Text = "{\n"
                        + "\"modelo\": \"65\",\n"
                        + "	\"serie\": \"" + tbConsultarSerie.Text + "\",\n"
                        + "	\"numero\": \"" + tbConsultarNumero.Text + "\",\n"
                        + "	\"formato\": \"" + "pdf" + "\"\n"
                        + "}\n";
                }
            }
            else
            {
                mediaType = Constantes.MEDIA_TYPE_JSON;

                if (!String.IsNullOrEmpty(tbConsultarChave.Text))
                {
                    rtbEnvio.Text = "{\n"
                    + "\"id\": \"" + tbConsultarChave.Text + "\",\n"
                    + "\"formato\": \"" + "json" + "\"\n"
                    + "}\n";
                }
                else
                {
                    rtbEnvio.Text = "{\n"
                        + "\"modelo\": \"65\",\n"
                        + "\"serie\": \"" + tbConsultarSerie.Text + "\",\n"
                        + "\"numero\": \"" + tbConsultarNumero.Text + "\",\n"
                        + "\"formato\": \"" + "json" + "\"\n"
                        + "}\n";
                }
            }

            if (rbDll.Checked)
            {
                //Consultar nota utilizando a DLL BemaOne32.dll
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_ConsultarNota(rtbEnvio.Text);
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;

                //Conversão do retorno para formato PDF e criação do arquivo.
                if (rbPdf.Checked)
                {

                    if (!String.IsNullOrEmpty(tbConsultarChave.Text))
                    {
                        base64ToPdf(strRetorno, tbConsultarChave.Text + ".pdf");
                    }
                    else
                    {
                        base64ToPdf(strRetorno, tbConsultarSerie.Text + "_" + tbConsultarNumero.Text + ".pdf");
                    }
                }
            }
            else
            {
                MyWebRequest myRequest = new MyWebRequest();

                try
                {
                    if (!String.IsNullOrEmpty(tbConsultarChave.Text))
                    {
                        var retorno = myRequest.getJson(Constantes.URL + Constantes.DOCUMENTO + "/" + tbConsultarChave.Text, mediaType);
                        rtbRetorno.Text = retorno;
                        Console.WriteLine(retorno);

                        //Conversão do retorno para formato PDF e criação do arquivo.
                        if (rbPdf.Checked)
                        {
                            if (!String.IsNullOrEmpty(tbConsultarChave.Text))
                            {
                                base64ToPdf(retorno, tbConsultarChave.Text + ".pdf");
                            }
                            else
                            {
                                base64ToPdf(retorno, tbConsultarSerie.Text + "_" + tbConsultarNumero.Text + ".pdf");
                            }
                        }

                    }
                    else if (!String.IsNullOrEmpty(tbConsultarSerie.Text) && !String.IsNullOrEmpty(tbConsultarNumero.Text))
                    {
                        var retorno = myRequest.getJson(Constantes.URL + Constantes.DOCUMENTO + "/65/" + tbConsultarSerie.Text + "/" + tbConsultarNumero.Text, mediaType);
                        rtbRetorno.Text = retorno;
                        Console.WriteLine(retorno);

                        //Conversão do retorno para formato PDF e criação do arquivo.
                        if (rbPdf.Checked)
                        {
                            if (!String.IsNullOrEmpty(tbConsultarChave.Text))
                            {
                                base64ToPdf(retorno, tbConsultarChave.Text + ".pdf");
                            }
                            else
                            {
                                base64ToPdf(retorno, tbConsultarSerie.Text + "_" + tbConsultarNumero.Text + ".pdf");
                            }
                        }
                    }
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + exp.Message);
                }
            }
        }
        /// <summary>
        /// Função que estorna a nota em aberto.
        /// </summary>
        private void estornarNota()
        {
            if (rbDll.Checked)
            {
                var retornoIntPtr = BemaOneDll.Bematech_Fiscal_EstornarNota();
                var strRetorno = Marshal.PtrToStringAnsi(retornoIntPtr);
                rtbRetorno.Text = strRetorno;
            }
            else
            {
                var resposta = String.Empty;
                var urlPost = Constantes.URL + Constantes.DOCUMENTO_CUPOM + "/" + sessao;

                MyWebRequest myRequest = new MyWebRequest();
                try
                {
                    var respostaJson = myRequest.delete(urlPost, Constantes.MEDIA_TYPE_JSON);
                    rtbRetorno.Text = respostaJson;
                }
                catch (Exception exp)
                {
                    MessageBox.Show("Ocorreu um erro: " + System.Environment.NewLine + exp.ToString() + System.Environment.NewLine);
                }
            }
        }
        #endregion

    }
}