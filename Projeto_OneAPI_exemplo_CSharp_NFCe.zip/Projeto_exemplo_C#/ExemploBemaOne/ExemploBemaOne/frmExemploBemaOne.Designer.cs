﻿namespace ExemploBemaOne
{
    partial class frmExemploBemaOne
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExemploBemaOne));
            this.btAbrir = new System.Windows.Forms.Button();
            this.btVender = new System.Windows.Forms.Button();
            this.btPagar = new System.Windows.Forms.Button();
            this.btFechar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.btStatus = new System.Windows.Forms.Button();
            this.btInformacaoSistema = new System.Windows.Forms.Button();
            this.btNotaErro = new System.Windows.Forms.Button();
            this.pnConsultarNota = new System.Windows.Forms.Panel();
            this.rbJson = new System.Windows.Forms.RadioButton();
            this.rbPdf = new System.Windows.Forms.RadioButton();
            this.btConsultarNota = new System.Windows.Forms.Button();
            this.pnChaveAcesso = new System.Windows.Forms.Panel();
            this.tbConsultarChave = new System.Windows.Forms.TextBox();
            this.lbChaveAcesso = new System.Windows.Forms.Label();
            this.pnSerieNumero = new System.Windows.Forms.Panel();
            this.tbConsultarSerie = new System.Windows.Forms.TextBox();
            this.tbConsultarNumero = new System.Windows.Forms.TextBox();
            this.lbNumeroConsulta = new System.Windows.Forms.Label();
            this.lbSerieConsulta = new System.Windows.Forms.Label();
            this.tbSerie = new System.Windows.Forms.TextBox();
            this.lbSerie = new System.Windows.Forms.Label();
            this.tbNumero = new System.Windows.Forms.TextBox();
            this.lbNumero = new System.Windows.Forms.Label();
            this.rtbEnvio = new System.Windows.Forms.RichTextBox();
            this.rtbRetorno = new System.Windows.Forms.RichTextBox();
            this.rtbTextoLivre = new System.Windows.Forms.RichTextBox();
            this.lbRetorno = new System.Windows.Forms.Label();
            this.lbEnvio = new System.Windows.Forms.Label();
            this.lbTextoLivre = new System.Windows.Forms.Label();
            this.cbGuilhotina = new System.Windows.Forms.CheckBox();
            this.btEnviar = new System.Windows.Forms.Button();
            this.pnTextoLivre = new System.Windows.Forms.Panel();
            this.rbDll = new System.Windows.Forms.RadioButton();
            this.rbApi = new System.Windows.Forms.RadioButton();
            this.pnCancelaNota = new System.Windows.Forms.Panel();
            this.tbCancelarChave = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btEstornar = new System.Windows.Forms.Button();
            this.lbCnpj = new System.Windows.Forms.Label();
            this.tbCnpj = new System.Windows.Forms.TextBox();
            this.pnConsultarNota.SuspendLayout();
            this.pnChaveAcesso.SuspendLayout();
            this.pnSerieNumero.SuspendLayout();
            this.pnTextoLivre.SuspendLayout();
            this.pnCancelaNota.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btAbrir
            // 
            this.btAbrir.Location = new System.Drawing.Point(13, 83);
            this.btAbrir.Name = "btAbrir";
            this.btAbrir.Size = new System.Drawing.Size(140, 23);
            this.btAbrir.TabIndex = 4;
            this.btAbrir.Text = "Abrir";
            this.btAbrir.UseVisualStyleBackColor = true;
            this.btAbrir.Click += new System.EventHandler(this.btAbrir_Click);
            // 
            // btVender
            // 
            this.btVender.Location = new System.Drawing.Point(13, 112);
            this.btVender.Name = "btVender";
            this.btVender.Size = new System.Drawing.Size(140, 23);
            this.btVender.TabIndex = 5;
            this.btVender.Text = "Vender";
            this.btVender.UseVisualStyleBackColor = true;
            this.btVender.Click += new System.EventHandler(this.btVender_Click);
            // 
            // btPagar
            // 
            this.btPagar.Location = new System.Drawing.Point(13, 141);
            this.btPagar.Name = "btPagar";
            this.btPagar.Size = new System.Drawing.Size(140, 23);
            this.btPagar.TabIndex = 6;
            this.btPagar.Text = "Pagar";
            this.btPagar.UseVisualStyleBackColor = true;
            this.btPagar.Click += new System.EventHandler(this.btPagar_Click);
            // 
            // btFechar
            // 
            this.btFechar.Location = new System.Drawing.Point(13, 170);
            this.btFechar.Name = "btFechar";
            this.btFechar.Size = new System.Drawing.Size(140, 23);
            this.btFechar.TabIndex = 7;
            this.btFechar.Text = "Fechar";
            this.btFechar.UseVisualStyleBackColor = true;
            this.btFechar.Click += new System.EventHandler(this.btFechar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(460, 8);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(90, 23);
            this.btCancelar.TabIndex = 2;
            this.btCancelar.Text = "Cancelar Nota";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // btStatus
            // 
            this.btStatus.Location = new System.Drawing.Point(12, 228);
            this.btStatus.Name = "btStatus";
            this.btStatus.Size = new System.Drawing.Size(140, 23);
            this.btStatus.TabIndex = 9;
            this.btStatus.Text = "Status Impressora";
            this.btStatus.UseVisualStyleBackColor = true;
            this.btStatus.Click += new System.EventHandler(this.btStatus_Click);
            // 
            // btInformacaoSistema
            // 
            this.btInformacaoSistema.Location = new System.Drawing.Point(12, 258);
            this.btInformacaoSistema.Name = "btInformacaoSistema";
            this.btInformacaoSistema.Size = new System.Drawing.Size(140, 23);
            this.btInformacaoSistema.TabIndex = 10;
            this.btInformacaoSistema.Text = "Informação Sistema";
            this.btInformacaoSistema.UseVisualStyleBackColor = true;
            this.btInformacaoSistema.Click += new System.EventHandler(this.btInformacaoSistema_Click);
            // 
            // btNotaErro
            // 
            this.btNotaErro.Location = new System.Drawing.Point(12, 287);
            this.btNotaErro.Name = "btNotaErro";
            this.btNotaErro.Size = new System.Drawing.Size(140, 23);
            this.btNotaErro.TabIndex = 11;
            this.btNotaErro.Text = "Nota com Rejeição";
            this.btNotaErro.UseVisualStyleBackColor = true;
            this.btNotaErro.Click += new System.EventHandler(this.btNotaErro_Click);
            // 
            // pnConsultarNota
            // 
            this.pnConsultarNota.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnConsultarNota.Controls.Add(this.rbJson);
            this.pnConsultarNota.Controls.Add(this.rbPdf);
            this.pnConsultarNota.Controls.Add(this.btConsultarNota);
            this.pnConsultarNota.Controls.Add(this.pnChaveAcesso);
            this.pnConsultarNota.Controls.Add(this.pnSerieNumero);
            this.pnConsultarNota.Location = new System.Drawing.Point(10, 401);
            this.pnConsultarNota.Name = "pnConsultarNota";
            this.pnConsultarNota.Size = new System.Drawing.Size(555, 75);
            this.pnConsultarNota.TabIndex = 4;
            // 
            // rbJson
            // 
            this.rbJson.AutoSize = true;
            this.rbJson.Checked = true;
            this.rbJson.Location = new System.Drawing.Point(398, 48);
            this.rbJson.Name = "rbJson";
            this.rbJson.Size = new System.Drawing.Size(53, 17);
            this.rbJson.TabIndex = 3;
            this.rbJson.TabStop = true;
            this.rbJson.Text = "JSON";
            this.rbJson.UseVisualStyleBackColor = true;
            // 
            // rbPdf
            // 
            this.rbPdf.AutoSize = true;
            this.rbPdf.Location = new System.Drawing.Point(345, 48);
            this.rbPdf.Name = "rbPdf";
            this.rbPdf.Size = new System.Drawing.Size(46, 17);
            this.rbPdf.TabIndex = 2;
            this.rbPdf.Text = "PDF";
            this.rbPdf.UseVisualStyleBackColor = true;
            // 
            // btConsultarNota
            // 
            this.btConsultarNota.Location = new System.Drawing.Point(460, 45);
            this.btConsultarNota.Name = "btConsultarNota";
            this.btConsultarNota.Size = new System.Drawing.Size(90, 23);
            this.btConsultarNota.TabIndex = 4;
            this.btConsultarNota.Text = "Consultar Nota";
            this.btConsultarNota.UseVisualStyleBackColor = true;
            this.btConsultarNota.Click += new System.EventHandler(this.btConsultarNota_Click);
            // 
            // pnChaveAcesso
            // 
            this.pnChaveAcesso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnChaveAcesso.Controls.Add(this.tbConsultarChave);
            this.pnChaveAcesso.Controls.Add(this.lbChaveAcesso);
            this.pnChaveAcesso.Location = new System.Drawing.Point(5, 5);
            this.pnChaveAcesso.Name = "pnChaveAcesso";
            this.pnChaveAcesso.Size = new System.Drawing.Size(545, 30);
            this.pnChaveAcesso.TabIndex = 0;
            // 
            // tbConsultarChave
            // 
            this.tbConsultarChave.Location = new System.Drawing.Point(153, 5);
            this.tbConsultarChave.Name = "tbConsultarChave";
            this.tbConsultarChave.Size = new System.Drawing.Size(382, 20);
            this.tbConsultarChave.TabIndex = 0;
            // 
            // lbChaveAcesso
            // 
            this.lbChaveAcesso.AutoSize = true;
            this.lbChaveAcesso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbChaveAcesso.Location = new System.Drawing.Point(5, 7);
            this.lbChaveAcesso.Name = "lbChaveAcesso";
            this.lbChaveAcesso.Size = new System.Drawing.Size(142, 16);
            this.lbChaveAcesso.TabIndex = 1;
            this.lbChaveAcesso.Text = "Chave de Acesso (ID):";
            // 
            // pnSerieNumero
            // 
            this.pnSerieNumero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnSerieNumero.Controls.Add(this.tbConsultarSerie);
            this.pnSerieNumero.Controls.Add(this.tbConsultarNumero);
            this.pnSerieNumero.Controls.Add(this.lbNumeroConsulta);
            this.pnSerieNumero.Controls.Add(this.lbSerieConsulta);
            this.pnSerieNumero.Location = new System.Drawing.Point(5, 40);
            this.pnSerieNumero.Name = "pnSerieNumero";
            this.pnSerieNumero.Size = new System.Drawing.Size(330, 30);
            this.pnSerieNumero.TabIndex = 1;
            // 
            // tbConsultarSerie
            // 
            this.tbConsultarSerie.Location = new System.Drawing.Point(50, 5);
            this.tbConsultarSerie.Name = "tbConsultarSerie";
            this.tbConsultarSerie.Size = new System.Drawing.Size(100, 20);
            this.tbConsultarSerie.TabIndex = 1;
            // 
            // tbConsultarNumero
            // 
            this.tbConsultarNumero.Location = new System.Drawing.Point(220, 5);
            this.tbConsultarNumero.Name = "tbConsultarNumero";
            this.tbConsultarNumero.Size = new System.Drawing.Size(100, 20);
            this.tbConsultarNumero.TabIndex = 3;
            // 
            // lbNumeroConsulta
            // 
            this.lbNumeroConsulta.AutoSize = true;
            this.lbNumeroConsulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumeroConsulta.Location = new System.Drawing.Point(160, 7);
            this.lbNumeroConsulta.Name = "lbNumeroConsulta";
            this.lbNumeroConsulta.Size = new System.Drawing.Size(59, 16);
            this.lbNumeroConsulta.TabIndex = 2;
            this.lbNumeroConsulta.Text = "Número:";
            // 
            // lbSerieConsulta
            // 
            this.lbSerieConsulta.AutoSize = true;
            this.lbSerieConsulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSerieConsulta.Location = new System.Drawing.Point(5, 7);
            this.lbSerieConsulta.Name = "lbSerieConsulta";
            this.lbSerieConsulta.Size = new System.Drawing.Size(43, 16);
            this.lbSerieConsulta.TabIndex = 0;
            this.lbSerieConsulta.Text = "Série:";
            // 
            // tbSerie
            // 
            this.tbSerie.Location = new System.Drawing.Point(62, 31);
            this.tbSerie.MaxLength = 14;
            this.tbSerie.Name = "tbSerie";
            this.tbSerie.Size = new System.Drawing.Size(95, 20);
            this.tbSerie.TabIndex = 1;
            // 
            // lbSerie
            // 
            this.lbSerie.AutoSize = true;
            this.lbSerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSerie.Location = new System.Drawing.Point(3, 32);
            this.lbSerie.Name = "lbSerie";
            this.lbSerie.Size = new System.Drawing.Size(43, 16);
            this.lbSerie.TabIndex = 0;
            this.lbSerie.Text = "Série:";
            // 
            // tbNumero
            // 
            this.tbNumero.Location = new System.Drawing.Point(62, 55);
            this.tbNumero.MaxLength = 14;
            this.tbNumero.Name = "tbNumero";
            this.tbNumero.Size = new System.Drawing.Size(95, 20);
            this.tbNumero.TabIndex = 3;
            // 
            // lbNumero
            // 
            this.lbNumero.AutoSize = true;
            this.lbNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumero.Location = new System.Drawing.Point(3, 56);
            this.lbNumero.Name = "lbNumero";
            this.lbNumero.Size = new System.Drawing.Size(59, 16);
            this.lbNumero.TabIndex = 2;
            this.lbNumero.Text = "Número:";
            // 
            // rtbEnvio
            // 
            this.rtbEnvio.Location = new System.Drawing.Point(169, 22);
            this.rtbEnvio.Name = "rtbEnvio";
            this.rtbEnvio.ReadOnly = true;
            this.rtbEnvio.Size = new System.Drawing.Size(377, 120);
            this.rtbEnvio.TabIndex = 12;
            this.rtbEnvio.Text = "";
            // 
            // rtbRetorno
            // 
            this.rtbRetorno.Location = new System.Drawing.Point(169, 167);
            this.rtbRetorno.Name = "rtbRetorno";
            this.rtbRetorno.ReadOnly = true;
            this.rtbRetorno.Size = new System.Drawing.Size(377, 120);
            this.rtbRetorno.TabIndex = 13;
            this.rtbRetorno.Text = "";
            // 
            // rtbTextoLivre
            // 
            this.rtbTextoLivre.Location = new System.Drawing.Point(5, 30);
            this.rtbTextoLivre.Name = "rtbTextoLivre";
            this.rtbTextoLivre.Size = new System.Drawing.Size(190, 374);
            this.rtbTextoLivre.TabIndex = 1;
            this.rtbTextoLivre.Text = "";
            // 
            // lbRetorno
            // 
            this.lbRetorno.AutoSize = true;
            this.lbRetorno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRetorno.Location = new System.Drawing.Point(325, 146);
            this.lbRetorno.Name = "lbRetorno";
            this.lbRetorno.Size = new System.Drawing.Size(56, 16);
            this.lbRetorno.TabIndex = 15;
            this.lbRetorno.Text = "Retorno";
            // 
            // lbEnvio
            // 
            this.lbEnvio.AutoSize = true;
            this.lbEnvio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEnvio.Location = new System.Drawing.Point(331, 3);
            this.lbEnvio.Name = "lbEnvio";
            this.lbEnvio.Size = new System.Drawing.Size(42, 16);
            this.lbEnvio.TabIndex = 14;
            this.lbEnvio.Text = "Envio";
            // 
            // lbTextoLivre
            // 
            this.lbTextoLivre.AutoSize = true;
            this.lbTextoLivre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTextoLivre.Location = new System.Drawing.Point(62, 8);
            this.lbTextoLivre.Name = "lbTextoLivre";
            this.lbTextoLivre.Size = new System.Drawing.Size(74, 16);
            this.lbTextoLivre.TabIndex = 0;
            this.lbTextoLivre.Text = "Texto Livre";
            // 
            // cbGuilhotina
            // 
            this.cbGuilhotina.AutoSize = true;
            this.cbGuilhotina.Location = new System.Drawing.Point(6, 417);
            this.cbGuilhotina.Name = "cbGuilhotina";
            this.cbGuilhotina.Size = new System.Drawing.Size(73, 17);
            this.cbGuilhotina.TabIndex = 2;
            this.cbGuilhotina.Text = "Guilhotina";
            this.cbGuilhotina.UseVisualStyleBackColor = true;
            // 
            // btEnviar
            // 
            this.btEnviar.Location = new System.Drawing.Point(137, 410);
            this.btEnviar.Name = "btEnviar";
            this.btEnviar.Size = new System.Drawing.Size(60, 23);
            this.btEnviar.TabIndex = 3;
            this.btEnviar.Text = "Enviar";
            this.btEnviar.UseVisualStyleBackColor = true;
            this.btEnviar.Click += new System.EventHandler(this.btEnviar_Click);
            // 
            // pnTextoLivre
            // 
            this.pnTextoLivre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnTextoLivre.Controls.Add(this.lbTextoLivre);
            this.pnTextoLivre.Controls.Add(this.cbGuilhotina);
            this.pnTextoLivre.Controls.Add(this.btEnviar);
            this.pnTextoLivre.Controls.Add(this.rtbTextoLivre);
            this.pnTextoLivre.Location = new System.Drawing.Point(575, 10);
            this.pnTextoLivre.Name = "pnTextoLivre";
            this.pnTextoLivre.Size = new System.Drawing.Size(200, 440);
            this.pnTextoLivre.TabIndex = 5;
            // 
            // rbDll
            // 
            this.rbDll.AutoSize = true;
            this.rbDll.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbDll.Location = new System.Drawing.Point(257, 4);
            this.rbDll.Name = "rbDll";
            this.rbDll.Size = new System.Drawing.Size(45, 17);
            this.rbDll.TabIndex = 0;
            this.rbDll.Text = "DLL";
            this.rbDll.UseVisualStyleBackColor = true;
            // 
            // rbApi
            // 
            this.rbApi.AutoSize = true;
            this.rbApi.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rbApi.Checked = true;
            this.rbApi.Location = new System.Drawing.Point(313, 4);
            this.rbApi.Name = "rbApi";
            this.rbApi.Size = new System.Drawing.Size(42, 17);
            this.rbApi.TabIndex = 1;
            this.rbApi.TabStop = true;
            this.rbApi.Text = "API";
            this.rbApi.UseVisualStyleBackColor = true;
            // 
            // pnCancelaNota
            // 
            this.pnCancelaNota.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnCancelaNota.Controls.Add(this.tbCancelarChave);
            this.pnCancelaNota.Controls.Add(this.label1);
            this.pnCancelaNota.Controls.Add(this.btCancelar);
            this.pnCancelaNota.Location = new System.Drawing.Point(10, 356);
            this.pnCancelaNota.Name = "pnCancelaNota";
            this.pnCancelaNota.Size = new System.Drawing.Size(555, 40);
            this.pnCancelaNota.TabIndex = 3;
            // 
            // tbCancelarChave
            // 
            this.tbCancelarChave.Location = new System.Drawing.Point(160, 10);
            this.tbCancelarChave.Name = "tbCancelarChave";
            this.tbCancelarChave.Size = new System.Drawing.Size(294, 20);
            this.tbCancelarChave.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chave de Acesso (ID):";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lbCnpj);
            this.panel1.Controls.Add(this.tbCnpj);
            this.panel1.Controls.Add(this.btEstornar);
            this.panel1.Controls.Add(this.btAbrir);
            this.panel1.Controls.Add(this.btVender);
            this.panel1.Controls.Add(this.btPagar);
            this.panel1.Controls.Add(this.btFechar);
            this.panel1.Controls.Add(this.btStatus);
            this.panel1.Controls.Add(this.lbEnvio);
            this.panel1.Controls.Add(this.lbSerie);
            this.panel1.Controls.Add(this.lbRetorno);
            this.panel1.Controls.Add(this.btInformacaoSistema);
            this.panel1.Controls.Add(this.rtbRetorno);
            this.panel1.Controls.Add(this.btNotaErro);
            this.panel1.Controls.Add(this.rtbEnvio);
            this.panel1.Controls.Add(this.tbSerie);
            this.panel1.Controls.Add(this.tbNumero);
            this.panel1.Controls.Add(this.lbNumero);
            this.panel1.Location = new System.Drawing.Point(10, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(554, 325);
            this.panel1.TabIndex = 2;
            // 
            // btEstornar
            // 
            this.btEstornar.Location = new System.Drawing.Point(13, 199);
            this.btEstornar.Name = "btEstornar";
            this.btEstornar.Size = new System.Drawing.Size(140, 23);
            this.btEstornar.TabIndex = 8;
            this.btEstornar.Text = "Estornar";
            this.btEstornar.UseVisualStyleBackColor = true;
            this.btEstornar.Click += new System.EventHandler(this.btEstornar_Click);
            // 
            // lbCnpj
            // 
            this.lbCnpj.AutoSize = true;
            this.lbCnpj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCnpj.Location = new System.Drawing.Point(3, 8);
            this.lbCnpj.Name = "lbCnpj";
            this.lbCnpj.Size = new System.Drawing.Size(46, 16);
            this.lbCnpj.TabIndex = 16;
            this.lbCnpj.Text = "CNPJ:";
            // 
            // tbCnpj
            // 
            this.tbCnpj.Location = new System.Drawing.Point(62, 7);
            this.tbCnpj.MaxLength = 14;
            this.tbCnpj.Name = "tbCnpj";
            this.tbCnpj.Size = new System.Drawing.Size(95, 20);
            this.tbCnpj.TabIndex = 17;
            // 
            // frmExemploBemaOne
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 501);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnCancelaNota);
            this.Controls.Add(this.rbApi);
            this.Controls.Add(this.rbDll);
            this.Controls.Add(this.pnTextoLivre);
            this.Controls.Add(this.pnConsultarNota);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmExemploBemaOne";
            this.Text = "Exemplo Bema One C#";
            this.pnConsultarNota.ResumeLayout(false);
            this.pnConsultarNota.PerformLayout();
            this.pnChaveAcesso.ResumeLayout(false);
            this.pnChaveAcesso.PerformLayout();
            this.pnSerieNumero.ResumeLayout(false);
            this.pnSerieNumero.PerformLayout();
            this.pnTextoLivre.ResumeLayout(false);
            this.pnTextoLivre.PerformLayout();
            this.pnCancelaNota.ResumeLayout(false);
            this.pnCancelaNota.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btAbrir;
        private System.Windows.Forms.Button btVender;
        private System.Windows.Forms.Button btPagar;
        private System.Windows.Forms.Button btFechar;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Button btStatus;
        private System.Windows.Forms.Button btInformacaoSistema;
        private System.Windows.Forms.Button btNotaErro;
        private System.Windows.Forms.Panel pnConsultarNota;
        private System.Windows.Forms.Panel pnChaveAcesso;
        private System.Windows.Forms.TextBox tbSerie;
        private System.Windows.Forms.TextBox tbConsultarChave;
        private System.Windows.Forms.Label lbChaveAcesso;
        private System.Windows.Forms.Label lbSerie;
        private System.Windows.Forms.Panel pnSerieNumero;
        private System.Windows.Forms.TextBox tbConsultarSerie;
        private System.Windows.Forms.TextBox tbConsultarNumero;
        private System.Windows.Forms.Label lbNumeroConsulta;
        private System.Windows.Forms.Label lbSerieConsulta;
        private System.Windows.Forms.TextBox tbNumero;
        private System.Windows.Forms.Label lbNumero;
        private System.Windows.Forms.Button btConsultarNota;
        private System.Windows.Forms.RichTextBox rtbEnvio;
        private System.Windows.Forms.RichTextBox rtbRetorno;
        private System.Windows.Forms.RichTextBox rtbTextoLivre;
        private System.Windows.Forms.Label lbRetorno;
        private System.Windows.Forms.Label lbEnvio;
        private System.Windows.Forms.Label lbTextoLivre;
        private System.Windows.Forms.CheckBox cbGuilhotina;
        private System.Windows.Forms.Button btEnviar;
        private System.Windows.Forms.Panel pnTextoLivre;
        private System.Windows.Forms.RadioButton rbDll;
        private System.Windows.Forms.RadioButton rbApi;
        private System.Windows.Forms.Panel pnCancelaNota;
        private System.Windows.Forms.TextBox tbCancelarChave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbJson;
        private System.Windows.Forms.RadioButton rbPdf;
        private System.Windows.Forms.Button btEstornar;
        private System.Windows.Forms.Label lbCnpj;
        private System.Windows.Forms.TextBox tbCnpj;
    }
}

