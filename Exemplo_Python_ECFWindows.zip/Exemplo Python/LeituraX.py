# -*- encoding: cp850 -*-
#Criado por Lucas Viana - BSP
import time
from ctypes import * 
from sys import *

library = WinDLL("bemafi32.dll")

iACK = c_int()
iST1 = c_int()
iST2 = c_int()
iST3 = c_int()

retorno = library.Bematech_FI_HabilitaDesabilitaRetornoEstendidoMFD("1")
retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
print "Retorno Habilita Retorno Estendido"
print iACK.value, iST1.value, iST2.value, iST3.value

while True:
	retorno = library.Bematech_FI_LeituraX()
	retorno = library.Bematech_FI_RetornoImpressoraMFD(byref(iACK),byref (iST1), byref(iST2), byref(iST3))
	print "Retorno da Leitura X"
	print iACK.value, iST1.value, iST2.value, iST3.value
	
	break

