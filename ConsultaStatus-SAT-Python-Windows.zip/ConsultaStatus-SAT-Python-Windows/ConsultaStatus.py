#!/usr/bin/env python
# -*- coding: latin-1 -*-

import ctypes
import marshal
import os
import datetime
from os import listdir
from ctypes import * 
from sys import * 
from random import randint

path = "./"
pathResult = "./"

directory = os.listdir(path)

contadorSucessoStatus = 0
contadorFalhaStatus = 0

contadorStatus = 1
contadorLoop = 0

contadorLoop = input("Digite o numero de vezes a ser executado: \n")
if contadorLoop <= 0:
	print("O numero deve ser maior do que zero.")
else:
	for contador in range(0, contadorLoop):
	
			# Chamar DLL
			library = ctypes.WinDLL(".\BemaSAT32.dll") # chamando a DLL
			

			print "\n\n\n\n -------------------------------------------------------------\n\n\n\n"
			
			#Consultar Status Operacional
			numsessao = c_int()


			numsessao = randint(000000,999999)
			print "\n\n\n\n -------------------------------------------------------------\n\n\n\n"
		
			print "\n Consulta Status Numero#: "+ str(contadorStatus) + " \n" 
			ret = library.ConsultarStatusOperacional(numsessao,"bema1234")
			print ret
			retorno = c_char_p(ret)
			print retorno.value
			array = retorno.value.split('|')
			print "RETORNO CONSULTA STATUS OPERACIONAL: " + array[1] + "|" + array[2] + "|" + array[3]
			print "\n\n\n\n -------------------------------------------------------------\n\n\n\n"
		

			if array[1] == "10000":
				print "SUCESSO\n"
				contadorSucessoStatus = contadorSucessoStatus + 1
				print "\n\nConsultar status Operacional - Sucessos: "+ str(contadorSucessoStatus)
				file1 = open(pathResult + "SUCESSO_STATUS.txt",'a')
				file1.write("\n Consulta Status Numero#: "+ str(contadorStatus) + " - " + str(datetime.datetime.now()) + ",\n")
				contadorStatus = contadorStatus + 1
			else:
				print "FALHA\n"
				contadorFalhaStatus = contadorFalhaStatus + 1
				print "\n\nConsultar Status Operacional - Falhas: "+ str(contadorFalhaStatus)
				file1 = open(pathResult + "FALHAS_STATUS.txt",'a')
				file1.write("\n Consulta Status Numero#: "+ str(contadorStatus) + " - " +  str(datetime.datetime.now()) + ",\n")
				contadorStatus = contadorStatus + 1



			
	print "\n\nTOTAL SUCESSOS: " + str(contadorSucessoStatus) + "\n"
	print "TOTAL FALHAS: " + str(contadorFalhaStatus) + "\n"

#Atualizado por Lucas Viana - BSP
